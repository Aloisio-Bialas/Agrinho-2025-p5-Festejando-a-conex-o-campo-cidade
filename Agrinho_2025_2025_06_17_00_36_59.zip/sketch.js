let liberar = 1;//permite mudar de cenários
let pontos = 0;//pontuação dos quizzis
//setas
let SetaDireita
let SetaEsquerda
//cor dos quizzis----------------
let cor1Q1 = 140;
let cor2Q1 = 140;
let cor1Q2 = 140;
let cor2Q2 = 140;
let cor1Q3 = 140;
let cor2Q3 = 140;
let cor1Q4 = 140;
let cor2Q4 = 140;
let cor1Q5 = 140;
let cor2Q5 = 140;
let cor1Q6 = 140;
let cor2Q6 = 140;
let cor1Q7 = 140;
let cor2Q7 = 140;
//respostas dos quizzis -----------------
let resposta = 0;
let resposta2 = 0;
let resposta3Q = 0;
let resposta4Q = 0;
let resposta5Q = 0;
let resposta6Q = 0;
let resposta7 = 0
//funções dos quizzis---------------
let borda = 190;
let borda2 = 110;
let borda3 = 110;
let borda4 = 110;
let borda5 = 110;
let borda6 = 110;
let borda7 = 110;
let borda8 = 110;
let borda9 = 110;
let borda10 = 110;
let bordaJogosY = 50;
let bordaJogosX = 30;
//variáveis cenários-------------------
let cenário = 1;
var INICIO;
var INICIO2;
var agrinho1;
var agrinho2;
var cenário6;
var cenário7;
var cenário8;
var cenário9;
var cenário10;
var cenário12;
var cenário13;
var cenário18;
let cenário20;
let cenário22;
let cenário23;
let cenário24;
let cenário25;
let cenário26;
let cenário27;
let cenário28;
let cenário29;
let cenário30;
let cenário31;
let cenário32;
let cenário33;
let JogoCaçaTesouro;
let campocidade;
let ExpJFotografia
let ExpJVelha
let ExpJMemória
let ExpJBolinha
let ExpJCaminhãozinho
let ExpJCaminhão
let ExpJTesouros
let ExpJReflorestamento
//outras variáveis------------------------
let cards = [];            // Cartas
let cols = 4;              // Número de colunas
let rows = 3;              // Número de linhas
let cardW, cardH;          // Largura e altura de cada carta
let symbols = ['🚜','🏙','🎉','🍽','👗','🌾']; 
let flippedCards = [];     
let lock = false;          
let tesouros = [];
let totaltesouros = 8;
let foundCount = 0;
let truck;
let collectible;
let gridSize = 20;
let gameOver = false;
let collectibles = ["🌽", "🧀", "☕", "🎶", "🏙", "🎭", "🍽", "🚜"];
let balls = [];
let spawnInterval = 1000;
let lastSpawnTime = 0;
let score = 0;
let timeLimit = 90;
let startTime;
let gameEnded = false;
let gameWon = false;  
let fireworkParticles = [];
//cor background 
let c1, c2;
let lerpAmt = 0;
//funções jogo desviar------------------------------
let truckImg;
let obstacleImg;
let truckX, truckY;
let truckWidth = 50, truckHeight = 100;
let truckSpeed = 5;
let obstacles = [];
let obstacleInterval = 3000;
let lastObstacleSpawn = 0;
let gameTimeLimit = 60000;
let startTime2;
let score2 = 0;
let gameOver2 = false;
let win = false;
let CaminhãoObstáculos = 1;
let board;
let currentPlayer;
let gameOver3 = false;
let boardSize = 350;
let boardOffset = 25;
let imgX, imgO;
const REQUIRED_TREES = 25;
let grassPatches = [];
let trees = [];
let temperature;
let gameStatus;
//jogo fotografia
let cameraImg;
let objetos = [];
let fotosTiradas = 0;
let todosFotografados = false;

//carregar imagens------------------

function preload(){
  INICIO = loadImage("cenário2(1).svg");
  INICIO2 = loadImage("cenário3..svg");
  agrinho1 = loadImage("cenário4..svg");
  agrinho2 = loadImage("cenário5..svg");
  cenário6 = loadImage("cenário6...svg");
  cenário7 = loadImage("cenário7.svg");
  cenário8 = loadImage("cenário8.svg");
  cenário9 = loadImage("cenário9.svg");
  cenário10 = loadImage("cenário10..svg");
  cenário12 = loadImage("cenário12..svg");
  cenário13 = loadImage("cenário13.svg");
  cenário15 = loadImage("cenário15.svg");
  cenário16 = loadImage("cenário16.svg");
  cenário18 = loadImage("cenário18.svg");
  cenário20 = loadImage("cenário20.svg");
  cenário22 = loadImage("cenário22.svg");
  cenário23 = loadImage("cenário23.svg");
  cenário24 = loadImage("cenário24.svg");
  cenário25 = loadImage("cenário25.svg");
  cenário26 = loadImage("cenário26.svg");
  cenário27 = loadImage("cenário27.svg");
  cenário28 = loadImage("cenário28.svg");
  cenário29 = loadImage("cenário29.svg");
  cenário30 = loadImage("cenário30.svg");
  cenário31 = loadImage("cenário31.svg");
  cenário32 = loadImage("cenário32.svg");
  cenário33 = loadImage("cenário33.svg");
  JogoCaçaTesouro = loadImage("jogo caça ao tesouro.svg");
  Bemvindo = loadImage("Bem vindo.svg");
  truckImg = loadImage("caminhão.svg");
  obstacleImg = loadImage("Buraco.svg");
  imgX = loadImage("CidadeX.svg");
  imgO = loadImage("CampoO.svg");
  imgCesta = loadImage("backdrop2.svg");
  imgBom = loadImage("backdrop3.svg");
  imgRuim = loadImage("backdrop4.svg");
  campocidade = loadImage("campo-cidade.svg");
  ExpJVelha = loadImage("Exp.J.Velha.svg");
  ExpJMemória = loadImage("Exp.J.Memória.svg");
  ExpJBolinha = loadImage("Exp.J.Bolinha.svg");
  SetaDireita = loadImage("SetaDireita.svg");
  SetaEsquerda = loadImage("SetaEsquerda.svg");
  cameraImg = loadImage("camera.svg");
  CenárioCamera = loadImage("CenárioCamera.svg");
  objetos.push(new Objeto(80, 150, loadImage("QuadradoCamera.svg"), "Trator"));
  objetos.push(new Objeto(200, 70, loadImage("QuadradoCamera.svg"), "Campo"));
  objetos.push(new Objeto(300, 250, loadImage("QuadradoCamera.svg"), "Cidade"));
  objetos.push(new Objeto(120, 320, loadImage("QuadradoCamera.svg"), "Antena de Internet"));
  objetos.push(new Objeto(350, 180, loadImage("QuadradoCamera.svg"), "Feira Rural"));
  ExpJCaminhãozinho = loadImage("Exp.J.Caminhãozinho.svg");
  ExpJCaminhão = loadImage("Exp.J.Caminhão.svg");
  ExpJTesouros = loadImage("Exp.J.Tesouros.svg");
  ExpJReflorestamento = loadImage("Exp.J.Reflorestamentp.svg");
  ExpJFotografia = loadImage("Exp.J.Foto.svg");
}

//------------------------------------------------

function setup() {
  createCanvas(400, 400);
  c1 = color(random(255), random(255), random(255));
  c2 = color(random(255), random(255), random(255));
  cardW = 80;
  cardH = 80; 
  let deck = symbols.concat(symbols);
  deck = shuffle(deck, true);
   let offsetX = (width - (cols * cardW)) / 2;
  let offsetY = (height - (rows * cardH)) / 2;
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      let index = i * cols + j;
      let card = {
        x: offsetX + j * cardW,
        y: offsetY + i * cardH,
        w: cardW,
        h: cardH,
        symbol: deck[index],
        flipped: false,
        matched: false
      };
      cards.push(card);
    }
  }
  let possibleEmojis = ["🎉", "🚜", "🌽", "🏙", "🍽", "🎶", "📚"];
  for (let i = 0; i < totaltesouros; i++) {
    let x = random(50, width - 100);
    let y = random(100, height - 100);
    let emoji = possibleEmojis[i % possibleEmojis.length];
    tesouros.push({
      x: x,
      y: y,
      emoji: emoji,
      found: false
    });
  }
  //caminhãozinho
  truck = new Truck();
  collectible = createCollectible();
  
  //caminhão
  truckX = width / 2 - truckWidth / 2;
  truckY = height - truckHeight - 20;
  
  //jogo da velha
  
  board = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
  ];
  currentPlayer = "x";//define o jogador inicial cidade
  gameOver3 = false;
  
  //jogo camêra
  cameraX = 200
  cameraY = 200
}


function draw() {  
  if(cenário === 1){
  let bgColor = lerpColor(c1, c2, lerpAmt);
  background(bgColor);
  lerpAmt += 0.01;
  
  if (lerpAmt >= 1) {
    c1 = c2;
    c2 = color(random(255), random(255), random(255));
    lerpAmt = 0;
  }}else if(cenário !== 1){
    background("white")
  }
  
  
  //definições para cada cenário----------------
  
  if(cenário === 1){
    frameRate(60)
    image (Bemvindo, -5, 200, 420, 205)
  }
  if(cenário === 50){
    textSize(15)
    text("Use as setas do teclado para mudar o cenario e ENTER para os quizzis", 100, 200, 300)
  }
  
  if (cenário === 2) {
    background("red"); 
    image (INICIO, 0, 0, 400, 400)
    textSize(15)
    text("Para voltar pressione a tecla (ESC)" , 110, 20)
  }
    if (cenário === 50){
    background("black"); 
    textSize(15)
    text("Para voltar pressione a tecla (ESC)" , 110, 20)
    fill("yellow");
  }
  if (cenário === 3) {
    image (INICIO2, 0, 0, 400, 400)
  }
  if (cenário === 4) {
    image (agrinho1, 0, 0, 400, 400)
  }
  if (cenário === 5) {
    image (agrinho2, 0, 0, 400, 400)
  }
  if (cenário === 6) {
    image (cenário6, 0, 0, 400, 400)
  }
  if (cenário === 7) {
    image (cenário7, 0, 0, 400, 400)
  }
  if (cenário === 8) {
    image (cenário8, 0, 0, 400, 400)
  }
  if (cenário === 9) {
    image (cenário9, 0, 0, 400, 400)
  }
  if (cenário === 10) {
    image (cenário10, 0, 0, 401, 400)
    liberar = 1
  }
  if (cenário === 11) {
    background("rgb(0,248,185)"); 
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    textSize(13)
    noStroke()
    fill("black");
    text("Agora que você sabe como a feira conecta o campo e a", 200, 70)
    text("cidade, marque a alternativa correta e ganhe pontos:", 200, 85)
    textSize(30)
    text("1:", 20, 80)
    fill(cor1Q1)
    rect(15, 110, 370, 60, 10)
    fill(cor2Q1)
    rect(15, 180, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    
      strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda2, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda2 - 2, 374, 64, 10);
  
  //perguntas:
    fill("black")
  noStroke()
    textSize(15)
  text("A feira propicia o intercâmbio entre agricultores e consumidores urbanos, fortalecendo a economia local.", 7, 125, 390)
    text("A feira é, praticamente, única um espaço de lazer, sem impacto na economia ou na relação campo/cidade.", 7, 195, 390)
    text("A feira serve somente para a venda de produtos industrializados, sem relação alguma com o campo.", 7, 265, 390)
    text("A feira não possibilita contato direto entre produtores e consumidores, não tendo relação entre campo e cidade.", 7, 335, 390)
}
  if (cenário === 12) {
    image (cenário12, 0, 0, 400, 400)
  }
  if (cenário === 13) {
    image (cenário13, 0, 0, 400, 400)
    liberar = 1
  }
  if (cenário === 14) {
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    
    
    textSize(13)
    noStroke()
    fill("black");
    text("Qual tecnologia no campo proporciona uma conexão entre", 200, 70)
    text("campo e cidade? Promovendo uma relação direta entre eles.", 200, 85)
    textSize(30)
    text("2:", 20, 80)
    fill(cor1Q2)
    rect(15, 110, 370, 60, 10)
    fill(cor2Q2)
    rect(15, 180, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda4, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda4 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(22)
    text("Drones de pulverização.", 7, 130, 390)
    text("Sensores de umidade no solo.", 7, 200, 390)
    text("Grandes máquinas agrícolas.", 7, 270, 390)
    text("Plataforma de vendas online.", 7, 340, 390)
}
  if (cenário === 15) {
    image (cenário15, 0, 0, 400, 400)
  }
  if (cenário === 16) {
    image (cenário16, 0, 0, 400, 400)
    liberar = 1;
  }
  if (cenário === 17) {
    resposta3 = 0;
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    
    
    textSize(13)
    noStroke()
    fill("black");
    text("Como festas típicas e celebrações proporcionam", 200, 70)
    text("uma conexão entre campo e cidade?", 200, 85)
    textSize(30)
    text("3:", 20, 80)
    fill(cor1Q3)
    rect(15, 180, 370, 60, 10)
    fill(cor2Q3)
    rect(15, 110, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda6, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda6 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("Únicamente promovendo competições desportivas entre residentes urbanos e rurais.", 7, 130, 390)
    text("Por meio da preservação cultural, do comércio de produtos provincianos e da interação social.", 7, 200, 370)
    text("Apenas através da exportação de produtos agrícolas para grandes centros urbanos.", 7, 270, 390)
    text("Apenas promovendo o turismo internacional em regiões rurais.", 7, 340, 380)
  }
  if (cenário === 18) {
    image (cenário18, 0, 0, 401, 401)
    liberar = 1
  }
  if (cenário === 19) {
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    
    
    textSize(13)
    noStroke()
    fill("black");
    text("Qual das alternativas a seguir apresenta um exemplo", 200, 70)
    text("de como a moda e os costumes rurais afetam a vida urbana?", 200, 85)
    textSize(30)
    text("4:", 20, 80)
    fill(cor1Q4)
    rect(15, 320, 370, 60, 10)
    fill(cor2Q4)
    rect(15, 180, 370, 60, 10)
    rect(15, 110, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda7, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda7 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("Só através do envio de produtos agrícolas dos centros rurais para os centros urbanos.", 7, 130, 370)
    text("Por meio da valorização das tradições rurais em roupas urbanas e da venda de produtos rurais", 7, 340, 370)
    text("Apenas pela absorção econômica da técnica agrícola nos locais urbanos.", 7, 270, 380)
    text("Somente pela criação de vestuário urbano em linha com as tendências internacionais.", 10, 200, 370)
  }
  if (cenário === 20) {
    image (cenário20, 0, 0, 400, 400)
    liberar = 1;
  }
  if (cenário === 21) {
    liberar = 2
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    
    
    textSize(13)
    noStroke()
    fill("black");
    text("Qual das alternativas a seguir apresenta um exemplo", 200, 70)
    text("de como a moda e os costumes rurais afetam a vida urbana?", 200, 85)
    textSize(30)
    text("5:", 20, 80)
    fill(cor2Q5)
    rect(15, 180, 370, 60, 10)
    rect(15, 110, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    fill(cor1Q5)
    rect(15, 250, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda8, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda8 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("Apenas pela troca de livros urbanos inspirados em tendências internacionais.", 7, 130, 370)
    text("Apenas por meio da troca de instrumentos musicais do campo por instrumentos da cidade.", 10, 200, 370)
    text("Por meio da valorização das tradições rurais na música e na literatura que atingem o público urbano.", 16, 270, 360)
    text("Apenas por meio da troca de estilos da música urbana por estilos da música rural.", 10, 340, 360)
  }
  if (cenário === 22) {
    image (cenário22, 0, 0, 400, 400)
  }
  if (cenário === 23) {
    image (cenário23, 0, 0, 400, 400)
  }
  if (cenário === 24) {
    image (cenário24, 0, 0, 400, 400)
  }
  if (cenário === 25) {
    image (cenário25, 0, 0, 400, 400)
  }
  if (cenário === 26) {
    image (cenário26, 0, 0, 402, 400)
  }
  if (cenário === 27) {
    image (cenário27, 0, 0, 400, 400)
  }
  if (cenário === 28) {
    image (cenário28, 0, 0, 400, 400)
    liberar = 1;
  }
  if (cenário === 29) {
    image (cenário29, 0, 0, 400, 400)
    liberar = 2;
    fill(cor1Q6)
    rect(15, 110, 370, 60, 10)
    fill(cor2Q6)
    rect(15, 180, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda9, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda9 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("As abelhas não são importantes, e poderiam ser extintas sem consequência alguma.", 10, 130, 370)
    text("Se as abelhas fossem extintas, o mundo acabaria em alguns anos, segundo Márcia d'Avila.", 10, 200, 370)
    text("As abelhas são polinizadoras essenciais para a biodiversidade e para a produção de alimentos.", 16, 270, 360)
    text("Segundo a (FAO), um terço da produção mundial de alimentos depende das abelhas.", 10, 340, 360)
  }
  if (cenário === 30) {
    image (cenário30, 0, 0, 402, 400)
  }
  if (cenário === 31) {
    image (cenário31, 0, 0, 400, 400)
  }
  if (cenário === 32) {
    image (cenário32, 0, 0, 400, 400)
    liberar = 1;
  }
  if (cenário === 33) {
    image (cenário33, 0, 0, 500, 500)
    liberar = 2;
    fill(cor2Q7)
    rect(15, 110, 370, 60, 10)
    rect(15, 180, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    fill(cor1Q7)
    rect(15, 320, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda10, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda10 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("A água é um dos principais elementos para a existência da vida humana.", 10, 130, 370)
    text("Quando o campo e a cidade trabalham juntos, há um aproveitamento de forma eficiente dos recursos hídricos.", 10, 200, 370)
    text("A água desempenha pepel fundamental tanto no campo como na cidade.", 16, 270, 360)
    text("Com a ausência de água, os meios rurais e urbanos não seriam afetados.", 10, 340, 360)
  }
  
  //EXPLIÇÃO JOGOS---------------------------------------
  
  if (cenário === 1001) {
    imageMode(CORNER);
    image (ExpJFotografia, 0, 0, 400, 400)
  }
  if (cenário === 1002) {
    image (ExpJVelha, 0, 0, 400, 400)
  }
  if (cenário === 1003) {
    image (ExpJMemória, 0, 0, 400, 400)
    strokeWeight(1)
    textSize(22)
    text("A seguir, os elementos presente no jogo:", 200, 260)
    textSize(25)
    text("🚜  🏙  🎉  🍽  👗  🌾", 200, 300)
  }
  if (cenário === 1004) {
    image (ExpJBolinha, 0, 0, 400, 400)
  }
  if (cenário === 1005) {
   // image (cenário26, 0, 0, 402, 400)
  }
  if (cenário === 1006) {
    image(ExpJCaminhãozinho, 0, 0, 400, 400)
  }
  if (cenário === 1007) {
    image (ExpJCaminhão, 0, 0, 400, 400)
  }
  if (cenário === 1008) {
    image (ExpJTesouros, 0, 0, 400, 400)
  }
  if (cenário === 1009) {
    image (ExpJReflorestamento, 0, 0, 400, 400)
  }
  
  //opções de jogos--------------------------------------
  if(cenário === 35){
    imageMode(CORNER);
    noStroke()
    fill("blue")
     rect(30, 50, 100, 70, 10)
     rect(150, 50, 100, 70, 10)
     rect(270, 50, 100, 70, 10)
     rect(30, 170, 100, 70, 10)
     rect(150, 170, 100, 70, 10)
     rect(270, 170, 100, 70, 10)
     rect(30, 290, 100, 70, 10)
     rect(150, 290, 100, 70, 10)
     rect(270, 290, 100, 70, 10)
    
    //borda------------
    stroke("black")
    strokeWeight(3)
    noFill()
    rect(bordaJogosX, bordaJogosY, 100, 70, 10)
     }
  
  if(cenário === 101){
    imageMode(CORNER);
    image(CenárioCamera, 0, 0, 400, 400)
    // Exibir objetos com suas imagens
  for (let obj of objetos) {
    obj.display();
  }

  // Exibir câmera como imagem;
  image(cameraImg, cameraX, cameraY, 50, 50);

  // Exibir mensagem se todos foram fotografados
  if (todosFotografados) {
    fill(0, 255, 0);
    textSize(20);
    textAlign(CENTER);
    text("Todos os elementos foram fotografados!", width / 2, height / 2);
  }
  }
  
  if(cenário === 103){
    for (let card of cards) {
    drawCard(card);
  }

  if (cards.every(card => card.matched)) {
    fill(0, 150);
    rect(0, 0, width, height);
    fill(255);
    textSize(20);
    text("Parabéns! Você uniu o Campo e a Cidade!", width / 2, height / 2);
  }
  }
  
  if(cenário === 108){
    image(JogoCaçaTesouro, 0, 0, 403, 420)
  textSize(18);
  for (let t of tesouros) {
    if (t.found) {
      fill(255, 255, 255, 255);
      text(t.emoji, t.x, t.y);
    } else {
      fill(255, 255, 255, 70);
      text(t.emoji, t.x, t.y);
    }
  }
    fill(0);
  textSize(20);
    noStroke()
  text("Caça ao Tesouro Cultural", width / 2, 30);
  text("Tesouros encontrados: " + foundCount + " / " + totaltesouros, width / 2, 60);
    
    if (foundCount === totaltesouros) {
    fill(0, 150);
    rect(0, 0, width, height);
    fill(255);
    textSize(19);
    text("Parabéns! Você achou todos os tesouros culturais!", width / 2, height / 2);
  }
}
  if(cenário === 106){
    frameRate(6)
    if (gameOver) {
    textSize(32);
    fill(255);
    textAlign(CENTER, CENTER);
    text("Game Over!", width / 2, height / 2);
    textSize(20);
    text("Pressione ENTER para reiniciar", width / 2, height / 2 + 40);
  }

  truck.update();
  truck.show();

  textSize(24);
  fill(255);
  textAlign(CENTER, CENTER);
  text(collectible.item, collectible.x + gridSize / 2, collectible.y + gridSize / 2);

  if (truck.collect(collectible)) {
    collectible = createCollectible();
  }

  if (truck.checkCollision() || truck.hitWall()) {
    gameOver = true;
  }
}
  
  if(cenário === 104){
    image(campocidade, -5, 255, 420, 150)
    timeLimit = 90;
    frameRate(50)
    let elapsed = (millis() - startTime) / 1000;
  let timeLeft = max(0, timeLimit - elapsed);

  if (!gameEnded) {
    // Gera novas bolinhas se o intervalo tiver passado
    if (millis() - lastSpawnTime > spawnInterval) {
      spawnBall();
      lastSpawnTime = millis();
    }
    
    // Atualiza e exibe cada bolinha
    for (let i = balls.length - 1; i >= 0; i--) {
      let b = balls[i];
      b.update();
      b.display();
      
      // Remove a bolinha se ela sair da tela (abaixo)
      if (b.y - b.radius > height) {
        balls.splice(i, 1);
      }
    }
    
    // Exibe a pontuação e o tempo restante (canto superior esquerdo)
    textSize(15)
    fill(0);
    noStroke(2);
    textAlign(CENTER, CENTER)
    text("Pontuação: " + score, 41, 20);
    text("Tempo: " + nf(timeLeft, 1, 1) + " s", 44, 40);
    
    // Verifica condições de fim de jogo
    if (score >= 500) {
      gameWon = true;
      gameEnded = true;
    }
    if (timeLeft <= 0 && score < 500) {
      gameEnded = true;
    }
  }
  
  // Se o jogo terminou, exibe a tela final
  if (gameEnded) {
    if (gameWon) {
      // Se os fogos de artifício ainda não foram gerados, gera-os
      if (fireworkParticles.length === 0) {
        spawnFireworks();
      }
      // Atualiza e exibe os fogos de artifício
      for (let i = fireworkParticles.length - 1; i >= 0; i--) {
        let p = fireworkParticles[i];
        p.update();
        p.display();
        if (p.life <= 0) {
          fireworkParticles.splice(i, 1);
        }
      }
      // Tela de vitória
      fill(0, 200);
      rect(0, 0, width, height);
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(28);
      text("Você ganhou!\nPontuação: " + score, width / 2, height / 2);
    } else {
      // Tela de derrota
      fill(0, 200);
      rect(0, 0, width, height);
      fill(255);
      textSize(28);
      text("Tempo esgotado!\nVocê perdeu!\nPontuação: " + score, 200, 200);
    }
  }
}
  if(cenário === 107){
    if(!win && !gameOver2){
  if (keyIsDown(LEFT_ARROW)) {
    truckX -= truckSpeed;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    truckX += truckSpeed;
  }}
    frameRate(50)
    noStroke();
  fill(70);
  beginShape();
    vertex(50, 400);
    vertex(350, 400);
    vertex(250, 0);
    vertex(150, 0);
  endShape(CLOSE);

  // Linha divisória central tracejada:
  stroke(255);
  strokeWeight(2);
  let dashCount = 10;
  for (let i = 0; i < dashCount; i++) {
    // A posição y será mapeada de 400 (fundo) a 0 (topo)
    let y1 = map(i, 0, dashCount, 400, 0);
    let y2 = map(i + 0.5, 0, dashCount, 400, 0);
    // Calcula os limites permitidos para um y médio
    let bounds = allowedXRange((y1 + y2) / 2);
    let centerX = (bounds.left + bounds.right) / 2;
    line(centerX, y1, centerX, y2);
  }
  noStroke();

  // Geração de obstáculos (são criados apenas se o jogo estiver ativo)
  if (!gameOver2 && !win && millis() - lastObstacleSpawn > obstacleInterval) {
    let spawnY = -50; // inicia acima do canvas
    // Para que nasçam dentro dos limites da estrada, usamos os limites para y = 0 (topo)
    let range = allowedXRange(0);
    let obsW = random(30, 50);
    let obsH = random(30, 50);
    // Gera x aleatório garantindo que o obstáculo caiba dentro da área permitida.
    let obsX = random(range.left, range.right - obsW);
    let obs = {
      x: obsX,
      y: spawnY,
      w: obsW,
      h: obsH,
      // Velocidade que aumenta gradualmente
      speed: 3 + (millis() - startTime2) / 20000
    };
    obstacles.push(obs);
    lastObstacleSpawn = millis();
  }
  
    if(!win && !gameOver2){
  // Atualiza e desenha os obstáculos; verifica colisão com o caminhão.
  for (let i = obstacles.length - 1; i >= 0; i--) {
    let obs = obstacles[i];
    obs.y += obs.speed;
      
    // Desenha o obstáculo como uma imagem usando "obstacleImg"
    image(obstacleImg, obs.x, obs.y, obs.w, obs.h);
    
    // Se houver colisão entre o caminhão e o obstáculo, termina o jogo.
    if (collideRectRect(truckX, truckY, truckWidth, truckHeight, obs.x, obs.y, obs.w, obs.h)) {
      obs.y = 420
      obstacles.splice(i, 1)
      if(!win){
      gameOver2 = true;
        obs.y = 420
    }
    }
    if(win){
      obs.y = 420
      obstacles.splice(i, 1)
    }
    
    // Remove obstáculos que já saíram da tela.
    if (obs.y > height) {
      obstacles.splice(i, 1);
    }
  }
  }
    
  // Constrange o caminhão aos limites laterais da estrada na parte inferior.
  let bottomBounds = allowedXRange(height - 1);
  truckX = constrain(truckX, bottomBounds.left, bottomBounds.right - truckWidth);

  // Desenha o caminhão (imagem)
  image(truckImg, truckX, truckY, truckWidth, truckHeight);

  // Atualiza a pontuação com base no tempo sobrevivido (em segundos).
  if (!gameOver2 && !win) {
    score2 = floor((millis() - startTime2) / 1000);
  }
  
  let elapsed = millis() - startTime2;
  let timeLeft = max(0, gameTimeLimit - elapsed);
  
  fill(0);
  textSize(16);
  text("Tempo: " + floor(timeLeft / 1000) + "s", 40, 20);
  text("Pontuação: " + score2, 50, 40);
  
  if (elapsed >= gameTimeLimit) {
    if(!gameOver2){
    win = true;
    }
  }
  
  if (gameOver2) {
    CaminhãoObstáculos = 2
    fill(255, 0, 0);
    strokeWeight(1)
    textSize(32);
    text("GAME OVER", 200, 200);
    textSize(25)
    text("Pressione ENTER para reiniciar.", 200, 240)
  }
  
  if (win) {
    CaminhãoObstáculos = 2
    fill(0, 255, 0);
    textSize(32);
    text("VOCÊ VENCEU!", 200, 200);
    textSize(25)
    text("Pressione ENTER para reiniciar.", 200, 240)
  }
}
  
  if(cenário === 102){
    
    strokeWeight(0)
    textSize(12)
  text("Em caso de empate ou se você quiser reiniciar o jogo clique ENTER.", 200, 395)
    
    if(currentPlayer === "x"){
      strokeWeight(1)
      textSize(15)
      fill(0)
      text("Jogador Atual: Cidade", 200, 16)
    } else if(currentPlayer === "o"){
      strokeWeight(1)
      fill(0)
      textSize(15)
     text("Jogador Atual: Campo", 200, 16)
    }
    
      drawBoard();
    gameOver3 = false;
    
    let winner = checkWinner();
  if (winner) {
    fill(255)
    rect(0, 0, 400, 400)
    gameOver3 = true;
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    strokeWeight(2)
    text("Vencedor: ", 144, 80);
    textSize(25)
    text("Pressione ENTER para reiniciar", 200, 300)
    // Exibe a imagem do jogador vencedor centralizada
    if (winner === "x") {
      text("Cidade", 260, 80)
      image(imgX, width / 2 - boardSize/6, height / 2 - boardSize/6, boardSize/3, boardSize/3);
    } else {
      text("Campo", 260, 80)
      image(imgO, width / 2 - boardSize/6, height / 2 - boardSize/6, boardSize/3, boardSize/3);
    }
  } else if (isBoardFull()) {
    gameOver3 = true;
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text("Empate!", width / 2, 150, 200);
  }
  }
  
  if(cenário === 109){
noStroke();
  fill(100, 200, 100);
  grassPatches.forEach(g => ellipse(g.x, g.y, g.r * 2));

  // desenha árvores plantadas
  trees.forEach(t => {
    fill(139, 69, 19);        // tronco
    rect(t.x - 5, t.y, 10, 20);
    fill(34, 139, 34);        // copa
    ellipse(t.x, t.y, 30);
  });

  // atualiza temperatura e verifica condições de fim de jogo
  if (gameStatus === 0) {
    temperature += (deltaTime / 1000) * 0.5;
    if (temperature >= 45) gameStatus = -1;
    if (trees.length >= REQUIRED_TREES) gameStatus = 1;
  }

  // HUD
  fill(0);
  textSize(20);
  textAlign(CENTER, CENTER);
  text(`Temperatura: ${temperature.toFixed(1)}°C`, 40, 20);
  text(`Árvores: ${trees.length}/${REQUIRED_TREES}`, 40, 45);

  // tela de vitória ou derrota
  if (gameStatus !== 0) {
    textAlign(CENTER, CENTER);
    textSize(36);
    if (gameStatus === 1) {
      fill(0, 150, 0);
      text("Você Ganhou!", width / 2, height / 2 - 20);
    } else {
      fill(150, 0, 0);
      text("Você Perdeu!", width / 2, height / 2 - 20);
    }
    textSize(20);
    fill(0);
    text("Pressione ENTER para reiniciar", width / 2, height / 2 + 20);
  }
  }
  
 //ínicio e botões---------------------------------
  if (cenário === 1){
  noStroke();
  fill("black");
  rect(100, 200, 200, 50, 20);
  rect(100, 300, 200, 50, 20);
  fill("blue");
  rect(100, 190, 200, 50, 20);
  rect(100, 290, 200, 50, 20);//desenha rect para formular botões
  
  strokeWeight(3)
  noFill();
  stroke(220, 220, 220);
  rect(100, borda, 200, 50, 20);
  
  noStroke();
  fill("black");
  textFont('Arial');
  textSize(30);
  textAlign(CENTER);
  text("Play", 200, 225);
  text("Explicações", 200, 325);
  textSize(50)
  stroke(0)
  strokeWeight(2);
  fill("yellow")
  text("BEM VINDO!", 200, 70)
  textSize(20)
  textFont('Oswald')
  text('Festejando a conexão CAMPO CIDADE', 200, 150)
  text('AGRINHO 2025', 200, 110)
  }
  
//demais códigos--------------------------------------
  
  //código setas exp jogos 
  
  if(cenário !== 1 && cenário !== 35 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109){
  image(SetaDireita, 355, 5, 40, 20)
    if(cenário !== 2 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109){
  image(SetaEsquerda, 5, 5, 40, 20)
  }
  }
    
  //Texto que aparece la em baixo em todos os quizzis
  
  if(cenário === 11 || cenário === 14 || cenário === 17 || cenário === 19 || cenário === 21 || cenário === 29 || cenário === 33){
    fill(0)
  textSize(12)
  text("Use as setas do teclado para selecionar a resposta e a tecla ENTER para confirma-lá.", 200, 395)
  }
  
   //outros códigos quizz1
  if(cenário === 11){
    liberar = 2
  if (resposta === 1){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  } else if (resposta === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    text("você errou! + 0 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  }
  }
  
  //outros códigos quizz2
  if(cenário === 14){
    liberar = 2
  if (resposta2 === 1){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  } else if (resposta2 === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  }
  }
  
  //outros códigos quizz3
  if(cenário === 17){
    liberar = 2
  if (resposta3Q === 1){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  } else if (resposta3Q === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  }
  }
  
  //outros códigos quizz4
  if(cenário === 19){
    liberar = 2
  if (resposta4Q === 1){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  } else if (resposta4Q === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  }
  }
  
  //outros códigos quizz5
  if(cenário === 21){
    liberar = 2
  if (resposta5Q === 1){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
    if (resposta5Q === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
  }
  
  //outros códigos quizz6
  if(cenário === 29){
    liberar = 2
  if (resposta6Q === 1){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
    if (resposta6Q === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
  }
  
  //outros códigos quizz7
  if(cenário === 33){
    liberar = 2
  if (resposta7 === 1){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
    if (resposta7 === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
  }
  
  //carregando----------------------------------------
  
  
//----------------------------------------------------
}
  
//função para teclas----------------------------------

function keyPressed() {
  if (cenário === 1){
  if (keyCode === UP_ARROW) {
    borda = 190;
  } else if (keyCode === DOWN_ARROW) {
    borda = 290;
  }}
  if (cenário === 1){
  if (keyCode === ENTER && borda === 190 ){
    cenário = 2;}
  else if(keyCode === ENTER && borda === 290){
    cenário = 50;}}
  if(cenário === 2){
  if (keyCode === 27 && cenário === 2){cenário = 1}}
 if (keyCode === 27 && cenário === 35){cenário = 34}
  if (keyCode === 27 && cenário === 101){cenário = 1001}
  if (keyCode === 27 && cenário === 102){cenário = 1002}
  if (keyCode === 27 && cenário === 103){cenário = 1003}
  if (keyCode === 27 && cenário === 104){cenário = 1004}
  if (keyCode === 27 && cenário === 105){cenário = 1005}
  if (keyCode === 27 && cenário === 106){cenário = 1006}
  if (keyCode === 27 && cenário === 107){cenário = 1007}
  if (keyCode === 27 && cenário === 108){cenário = 1008}
  if (keyCode === 27 && cenário === 109){cenário = 1009}
  if (keyCode === LEFT_ARROW && cenário === 1001){cenário = 35}
  else if (keyCode === LEFT_ARROW && cenário === 1002){cenário = 35}
  else if (keyCode === LEFT_ARROW && cenário === 1003){cenário = 35}
  else if (keyCode === LEFT_ARROW && cenário === 1004){cenário = 35}
  else if (keyCode === LEFT_ARROW && cenário === 1005){cenário = 35}
  else if (keyCode === LEFT_ARROW && cenário === 1006){cenário = 35}
  else if (keyCode === LEFT_ARROW && cenário === 1007){cenário = 35}
  else if (keyCode === LEFT_ARROW && cenário === 1008){cenário = 35}
  else if (keyCode === LEFT_ARROW && cenário === 1009){cenário = 35}
  if(cenário === 50){
  if (keyCode === 27){cenário = 1}}
  if (cenário !== 1 && cenário !== 50) {
    if (keyCode === RIGHT_ARROW && liberar === 1 && cenário !== 35 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109 && cenário !== 1001 && cenário !== 1002 && cenário !== 1003 && cenário !== 1004 && cenário !== 1005 && cenário !== 1006 && cenário !== 1007& cenário !== 1008 && cenário !== 1009){
      cenário = cenário +1
    }
    if ( keyCode === LEFT_ARROW && cenário !== 2 && cenário !== 1 && cenário !== 50 && cenário !== 35 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109 && cenário !== 1001 && cenário !== 1002 && cenário !== 1003 && cenário !== 1004 && cenário !== 1005 && cenário !== 1006 && cenário !== 1007& cenário !== 1008 && cenário !== 1009) {
      cenário = cenário -1
    }}
  
  
  //códigos para fazer o quizz1----------------
  
  if (cenário === 11){
  if (keyCode === UP_ARROW && borda2 !== 110 && resposta !== 1 && resposta !== 2) {
    borda2 = borda2 - 70;
  } else if (keyCode === DOWN_ARROW && borda2 !== 320 && resposta !== 1 && resposta !== 2) {
    borda2 = borda2 + 70;
  }
  if (keyCode === ENTER && borda2 === 110 && resposta !== 1 && resposta !== 2){
    resposta = 1 
  cor1Q1 = "green"
  pontos = pontos + 10;
  } else if(keyCode === ENTER && borda2 !== 110){
    resposta = 2
    cor1Q1 = "green"
    cor2Q1 = "red"
  }}
     
  //código para fazer o quizz2--------------
    if (cenário === 14){
  if (keyCode === UP_ARROW && borda4 !== 110 && resposta2 !== 1 && resposta2 !== 2) {
    borda4 = borda4 - 70;
  } else if (keyCode === DOWN_ARROW && borda4 !== 320 && resposta2 !== 1 && resposta2 !== 2) {
    borda4 = borda4 + 70;
  }
  if (keyCode === ENTER && borda4 === 110 && resposta2 !== 1 && resposta2 !== 2){
    resposta2 = 1 
  cor1Q2 = "green"
  pontos = pontos + 10;
  } else if(keyCode === ENTER && borda4 !== 110){
    resposta2 = 2
    cor2Q2 = "red"
    cor1Q2= "green"
  }}
  //------------------------------------------------
  
  //código para fazer o quizz3--------------
  
      if (cenário === 17){
  if (keyCode === UP_ARROW && borda6 !== 110 && resposta3Q !== 1 && resposta3Q !== 2) {
    borda6 = borda6 - 70;
  } else if (keyCode === DOWN_ARROW && borda6 !== 320 && resposta3Q !== 1 && resposta3Q !== 2) {
    borda6 = borda6 + 70;
  }
  if (keyCode === ENTER && borda6 === 180 && resposta3Q !== 1 && resposta3Q !== 2){
    resposta3Q = 1 
  cor1Q3 = "green"
  pontos = pontos + 10;
  } else if(keyCode === ENTER && borda6 !== 180){
    resposta3Q = 2
    cor2Q3 = "red"
    cor1Q3= "green"
  }}
  
  //------------------------------------------------
  
  //código para o quizz4----------------------------
        
        if (cenário === 19){
  if (keyCode === UP_ARROW && borda7 !== 110 && resposta4Q !== 1 && resposta4Q !== 2) {
    borda7 = borda7 - 70;
  } else if (keyCode === DOWN_ARROW && borda7 !== 320 && resposta4Q !== 1 && resposta4Q !== 2) {
    borda7 = borda7 + 70;
  }
  if (keyCode === ENTER && borda7 === 320 && resposta4Q !== 1 && resposta4Q !== 2){
    resposta4Q = 1
  cor1Q4 = "green"
   pontos = pontos + 10;
  } else if(keyCode === ENTER && borda7 !== 320){
    resposta4Q = 2
    cor2Q4 = "red"
    cor1Q4= "green"
  }}

    //--------------------------------------------------
  
  //código para o quizz5----------------------------
        
        if (cenário === 21){
  if (keyCode === UP_ARROW && borda8 !== 110 && resposta5Q !== 1 && resposta5Q !== 2) {
    borda8 = borda8 - 70;
  } else if (keyCode === DOWN_ARROW && borda8 !== 320 && resposta5Q !== 1 && resposta5Q !== 2) {
    borda8 = borda8 + 70;
  }
  if (keyCode === ENTER && borda8 === 250 && resposta5Q !== 1 && resposta5Q !== 2){
    resposta5Q = 1
  cor1Q5 = "green"
    pontos = pontos + 10;
  } else if(keyCode === ENTER && borda8 !== 250){
    resposta5Q = 2
    cor2Q5 = "red"
    cor1Q5= "green"
  }}

    //--------------------------------------------------
  
  //código para o quizz6----------------------------
        
        if (cenário === 29){
  if (keyCode === UP_ARROW && borda9 !== 110 && resposta6Q !== 1 && resposta6Q !== 2) {
    borda9 = borda9 - 70;
  } else if (keyCode === DOWN_ARROW && borda9 !== 320 && resposta6Q !== 1 && resposta6Q !== 2) {
    borda9 = borda9 + 70;
  }
  if (keyCode === ENTER && borda9 === 110 && resposta6Q !== 1 && resposta6Q !== 2){
    resposta6Q = 1
  cor1Q6 = "green"
    pontos = pontos + 10;
  } else if(keyCode === ENTER && borda9 !== 110){
    resposta6Q = 2
    cor2Q6 = "red"
    cor1Q6= "green"
  }}

    //--------------------------------------------------
  
  //código para o quizz7----------------------------
        
        if (cenário === 33){
  if (keyCode === UP_ARROW && borda10 !== 110 && resposta7 !== 1 && resposta7 !== 2) {
    borda10 = borda10 - 70;
  } else if (keyCode === DOWN_ARROW && borda10 !== 320 && resposta7 !== 1 && resposta7 !== 2) {
    borda10 = borda10 + 70;
  }
  if (keyCode === ENTER && borda10 === 320 && resposta7  !== 1 && resposta7 !== 2){
    resposta7 = 1
  cor1Q7 = "green"
    pontos = pontos + 10;
  } else if(keyCode === ENTER && borda10 !== 320){
    resposta7 = 2
    cor2Q7 = "red"
    cor1Q7= "green"
  }}

    //--------------------------------------------------
  
  //Teclas jogos-------------------------------
  if(cenário === 35){
    if (keyCode === UP_ARROW && bordaJogosY !== 50) {
    bordaJogosY -= 120;
  } else if (keyCode === DOWN_ARROW && bordaJogosY !== 290) {
    bordaJogosY += 120;
  }
   if (keyCode === RIGHT_ARROW && bordaJogosX !== 270) {
    bordaJogosX += 120;
  } else if (keyCode === LEFT_ARROW && bordaJogosX !== 30) {
    bordaJogosX -= 120;
  }
  }
  if(cenário === 35){
  if (keyCode === ENTER && bordaJogosX === 30 && bordaJogosY === 50){
    cenário = 1001
  }
  if (keyCode === ENTER && bordaJogosX === 150 && bordaJogosY === 50){
    cenário = 1002
  }
  if (keyCode === ENTER && bordaJogosX === 270 && bordaJogosY === 50){
    cenário = 1003
  }
  if (keyCode === ENTER && bordaJogosX === 30 && bordaJogosY === 170){
    cenário = 1004
  }
  if (keyCode === ENTER && bordaJogosX === 150 && bordaJogosY === 170){
    cenário = 1005
  }
  if (keyCode === ENTER && bordaJogosX === 270 && bordaJogosY === 170){
    cenário = 1006
  }
  if (keyCode === ENTER && bordaJogosX === 30 && bordaJogosY === 290){
    cenário = 1007
  }
  if (keyCode === ENTER && bordaJogosX === 150 && bordaJogosY === 290){
    cenário = 1008
  }
  if (keyCode === ENTER && bordaJogosX === 270 && bordaJogosY === 290){
    cenário = 1009
  }
  } 
  if (keyCode === RIGHT_ARROW && cenário === 1001){
    cenário = 101
    cameraX = 200
  cameraY = 200
  }
  if (keyCode === RIGHT_ARROW && cenário === 1002){
    cenário = 102
  }
  if (keyCode === RIGHT_ARROW && cenário === 1003){
    cenário = 103
  }
  if (keyCode === RIGHT_ARROW && cenário === 1004){
    cenário = 104
    startTime = millis();
  lastSpawnTime = millis();
    score = 0
  }
  if (keyCode === RIGHT_ARROW && cenário === 1005){
    cenário = 105
  }
  if (keyCode === RIGHT_ARROW && cenário === 1006){
    cenário = 106
  }
  if (keyCode === RIGHT_ARROW && cenário === 1007){
    cenário = 107
    obsY = -50
    startTime2 = millis();
    gameOver2 = false;
    win = false
    truckX = width / 2 - truckWidth / 2;
    truckY = height - truckHeight - 20;
  }
  if (keyCode === RIGHT_ARROW && cenário === 1008){
    cenário = 108
  }
  if (keyCode === RIGHT_ARROW && cenário === 1009){
    cenário = 109
    initGame();
  }
  
  //teclas jogo caminhãozinho---------------------
  
  if(cenário === 106){
    
  if (keyCode === UP_ARROW && truck.ydir === 0) {
    truck.setDirection(0, -1);
  } else if (keyCode === DOWN_ARROW && truck.ydir === 0) {
    truck.setDirection(0, 1);
  } else if (keyCode === LEFT_ARROW && truck.xdir === 0) {
    truck.setDirection(-1, 0);
  } else if (keyCode === RIGHT_ARROW && truck.xdir === 0) {
    truck.setDirection(1, 0);
  } else if (keyCode === ENTER && gameOver) {
    restartGame();
  }
  }
       
  //jogo arvore
  
  if (keyCode === ENTER && gameStatus !== 0 && cenário === 109) {
    initGame();
  }
  if (keyCode === ENTER && cenário === 102) {
    gameOver3 = false;
    board = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
  ];
  }
  
  if (keyCode === ENTER && cenário === 107 && win){
        startTime2 = millis();
    gameOver2 = false;
    win = false
    truckX = width / 2 - truckWidth / 2;
    truckY = height - truckHeight - 20;
  }
  if (keyCode === ENTER && cenário === 107 && gameOver2){
        startTime2 = millis();
    gameOver2 = false;
    win = false
    truckX = width / 2 - truckWidth / 2;
    truckY = height - truckHeight - 20;
  }
  //jogo camera
  
  if(cenário === 101){
    if(todosFotografados === false){
  if (keyCode === LEFT_ARROW) cameraX -= 20;
  if (keyCode === RIGHT_ARROW) cameraX += 20;
  if (keyCode === UP_ARROW) cameraY -= 20;
  if (keyCode === DOWN_ARROW) cameraY += 20;
    }

  // Simular captura da foto
  
  if (key === ' ') {
    for (let obj of objetos) {
      if (!obj.fotografado && dist(cameraX, cameraY, obj.x, obj.y) < 50) {
        obj.fotografado = true;
        fotosTiradas++;
        console.log("Foto tirada de: " + obj.nome);
      }
    }
    
    // Verifica se todos foram fotografados
    if (fotosTiradas === objetos.length) {
      todosFotografados = true;
    }
  }
  }
}

//jogo da memória----------------------------
function drawCard(card) {
  stroke(0);
  strokeWeight(2);
  // Se a carta está virada ou já combinada, mostra o símbolo
  if (card.flipped || card.matched) {
    fill(255);
    rect(card.x, card.y, card.w, card.h, 10);
    textSize(32);
    fill(0);
    text(card.symbol, card.x + card.w / 2, card.y + card.h / 2);
  } 
  else {
    // Carta com verso (oculta)
    fill(100);
    rect(card.x, card.y, card.w, card.h, 10);
  }
}
// ------------------------------------------

function mousePressed() {
  //setas mudar cenários
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário !== 1 && cenário !== 1001 && cenário !== 1002 && cenário !== 1003 && cenário !== 1004 && cenário !== 1005 && cenário !== 1006 && cenário !== 1007 && cenário !== 1008 && cenário !== 1009 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109){
    cenário = cenário - 1
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário !== 1 && cenário !== 1001 && cenário !== 1002 && cenário !== 1003 && cenário !== 1004 && cenário !== 1005 && cenário !== 1006 && cenário !== 1007 && cenário !== 1008 && cenário !== 1009 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109 && liberar === 1){
    cenário = cenário + 1
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1001){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1001 && liberar === 1){
    cenário = 101
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1002){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1002 && liberar === 1){
    cenário = 102
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1003){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1003 && liberar === 1){
    cenário = 103
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1004){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1004 && liberar === 1){
    cenário = 104
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1005){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1005 && liberar === 1){
    cenário = 105
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1006){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1006 && liberar === 1){
    cenário = 106
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1007){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1007 && liberar === 1){
    cenário = 107
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1008){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1008 && liberar === 1){
    cenário = 108
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1009){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1009 && liberar === 1){
    cenário = 109
  }
  //---------------------

  
  if(cenário === 103){
  if (lock) return; // ignora cliques
  
  // Verifica se o clique ocorreu dentro de alguma carta
  for (let card of cards) {
    if (mouseX >= card.x && mouseX <= card.x + card.w &&
        mouseY >= card.y && mouseY <= card.y + card.h) {
      if (!card.flipped && !card.matched) {
        card.flipped = true;
        flippedCards.push(card);
      }
    }
  }
  
  if (flippedCards.length === 2) {
    lock = true;
    if (flippedCards[0].symbol === flippedCards[1].symbol) {
      flippedCards[0].matched = true;
      flippedCards[1].matched = true;
      flippedCards = [];
      lock = false;
    } else {
      setTimeout(() => {
        flippedCards[0].flipped = false;
        flippedCards[1].flipped = false;
        flippedCards = [];
        lock = false;
      }, 1000);
    }
  }
  }
  if(cenário === 108){
  for (let t of tesouros) {
    if (!t.found) {
      let d = dist(mouseX, mouseY, t.x, t.y);
      if (d < 30) {
        t.found = true;
        foundCount++;
      }
    }
  }
  }
  if (!gameEnded) {
    // Verifica cada bolinha para ver se o clique ocorreu sobre ela
    for (let i = balls.length - 1; i >= 0; i--) {
      let b = balls[i];
      let d = dist(mouseX, mouseY, b.x, b.y);
      if (d < b.radius) {
        score += 10;           // Soma 10 pontos por bolinha coletada
        balls.splice(i, 1);    // Remove a bolinha coletada
      }
    }
  }
  if (gameOver3) return;
  
  if(cenário === 102){
  // Verifica se o clique está dentro da área do tabuleiro
  if (mouseX < boardOffset || mouseX > boardOffset + boardSize ||
      mouseY < boardOffset || mouseY > boardOffset + boardSize) {
    return;
  }
  
  let col = floor((mouseX - boardOffset) / (boardSize / 3));
  let row = floor((mouseY - boardOffset) / (boardSize / 3));
  
  if (board[row][col] === '') {
    board[row][col] = currentPlayer;
    currentPlayer = (currentPlayer === "x") ? "o" : "x";
  }
  }
  
  //reflorestamento jogo
  if (gameStatus !== 0) return;
  // evita plantar sobre mato ou sobre outra árvore
  if (grassPatches.some(g => dist(mouseX, mouseY, g.x, g.y) < g.r)) return;
  if (trees.some(t => dist(mouseX, mouseY, t.x, t.y) < 15)) return;
  trees.push({ x: mouseX, y: mouseY });
}
//--------------------------------------

//Jogo caminhãzinho---------------------------------
function createCollectible() {
  return {
    x: floor(random(width / gridSize)) * gridSize,
    y: floor(random(height / gridSize)) * gridSize,
    item: random(collectibles),
  };
}

function restartGame() {
  gameOver = false;
  truck = new Truck();
  collectible = createCollectible();
}

class Truck {
  constructor() {
    this.body = [createVector(gridSize, gridSize)];
    this.xdir = 1;
    this.ydir = 0;
  }

  update() {
    let head = this.body[this.body.length - 1].copy();
    head.x += this.xdir * gridSize;
    head.y += this.ydir * gridSize;

    if (this.hitWall()) {
      gameOver = true;
      return;
    }

    this.body.push(head);

    if (!this.collecting) {
      this.body.shift();
    } else {
      this.collecting = false;
    }
  }

  show() {
    for (let i = 0; i < this.body.length; i++) {
      let segment = this.body[i];

      // Cor do caminhão
      fill(200, 0, 0);
      stroke(50);
      strokeWeight(2);
      rect(segment.x, segment.y, gridSize, gridSize, 5);

      // Caçamba traseira
      fill(150);
      rect(segment.x + 4, segment.y - 5, gridSize - 8, 10, 3);

      // Janelas do caminhão
      fill(180, 220, 255);
      rect(segment.x + 6, segment.y + 2, gridSize - 12, 10, 3);

      // Rodas
      fill(0);
      ellipse(segment.x + 5, segment.y + gridSize - 3, 6, 6);
      ellipse(segment.x + gridSize - 5, segment.y + gridSize - 3, 6, 6);
    }
  }
  setDirection(x, y) {
    this.xdir = x;
    this.ydir = y;
  }

  collect(position) {
    let head = this.body[this.body.length - 1];
    if (head.x === position.x && head.y === position.y) {
      this.collecting = true;
      return true;
    }
    return false;
  }

  checkCollision() {
    let head = this.body[this.body.length - 1];
    for (let i = 0; i < this.body.length - 1; i++) {
      if (head.x === this.body[i].x && head.y === this.body[i].y) {
        return true;
      }
    }
    return false;
  }

  hitWall() {
    let head = this.body[this.body.length - 1];
    return head.x < 0 || head.x >= width || head.y < 0 || head.y >= height;
  }
}

//jogo bolinhas----------------------------

function spawnBall() {
  let radius = random(15, 30);                        // Raio aleatório entre 15 e 30
  let x = random(radius, width - radius);             // Posição horizontal aleatória
  let y = -radius;                                    // Inicia acima da tela
  let speed = random(2, 6);                           // Velocidade aleatória
  balls.push(new Ball(x, y, radius, speed));
}

function spawnFireworks() {
  for (let i = 0; i < 100; i++) {
    let angle = random(TWO_PI);
    let speed = random(2, 6);
    fireworkParticles.push(new Firework(width/2, height/2, angle, speed));
  }
}
class Ball {
  constructor(x, y, radius, speed) {
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.speed = speed;
  }
  
  update() {
    this.y += this.speed;
  }
  
  display() {
    fill(255, 0, 0);
    noStroke();
    ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
  }
}

class Firework {
  constructor(x, y, angle, speed) {
    this.x = x;
    this.y = y;
    this.vx = speed * cos(angle);
    this.vy = speed * sin(angle);
    this.size = random(4, 8);
    this.color = color(random(200,255), random(100,255), random(100,255));
    this.life = 255;
  }
  
  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += 0.05;
    this.life -= 4;
  }
  
  display() {
    noStroke();
    fill(red(this.color), green(this.color), blue(this.color), this.life);
    ellipse(this.x, this.y, this.size, this.size);
  }
}
function drawProgressBar(x, y, w, h, value, maxVal, label, col) {
  stroke(0);
  fill(255);
  rect(x, y, w, h);
  noStroke();
  fill(col);
  let barWidth = map(value, 0, maxVal, 0, w);
  rect(x, y, barWidth, h);
  fill(0);
  textAlign(LEFT, CENTER);
  text(label + " (" + floor(value) + "/" + maxVal + ")", x, y + h + 12);
}

//jogo caminhão obstaculos
function allowedXRange(y) {
  // Considera y entre 0 (topo) e 400 (fundo)
  let clampedY = constrain(y, 0, 400);
  // Quando y=0, os limites devem ser 150 e 250.
  // Quando y=400, os limites são 50 e 350.
  let leftBound = map(clampedY, 400, 0, 50, 150);
  let rightBound = map(clampedY, 400, 0, 350, 250);
  return { left: leftBound, right: rightBound };
}

// Função de colisão entre retângulos.
function collideRectRect(x1, y1, w1, h1, x2, y2, w2, h2) {
  return (x1 < x2 + w2 &&
          x1 + w1 > x2 &&
          y1 < y2 + h2 &&
          y1 + h1 > y2);
}

//jogo da velha -------------------------------------------

function drawBoard() {
  // Desenha o tabuleiro (grade) dentro da área de 350x350 com offset
  strokeWeight(4);
  // Linhas verticais
  for (let i = 1; i < 3; i++) {
    let x = boardOffset + i * (boardSize / 3);
    line(x, boardOffset, x, boardOffset + boardSize);
  }
  // Linhas horizontais
  for (let i = 1; i < 3; i++) {
    let y = boardOffset + i * (boardSize / 3);
    line(boardOffset, y, boardOffset + boardSize, y);
  }
  
  // Desenha as imagens nas células conforme a marcação
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      let x = boardOffset + j * (boardSize / 3);
      let y = boardOffset + i * (boardSize / 3);
      if (board[i][j] === "x") {
        image(imgX, x + 1, y, 114, 114);
      } else if (board[i][j] === "o") {
        image(imgO, x + 2, y + 3, 112, 111);
      }
    }
  }
}

function checkWinner() {
  let winner = null;
  
  // Verifica linhas
  for (let i = 0; i < 3; i++) {
    if (board[i][0] !== '' &&
        board[i][0] === board[i][1] &&
        board[i][1] === board[i][2]) {
      winner = board[i][0];
    }
  }
  
  // Verifica colunas
  for (let j = 0; j < 3; j++) {
    if (board[0][j] !== '' &&
        board[0][j] === board[1][j] &&
        board[1][j] === board[2][j]) {
      winner = board[0][j];
    }
  }
  
  // Verifica diagonais
  if (board[0][0] !== '' &&
      board[0][0] === board[1][1] &&
      board[1][1] === board[2][2]) {
    winner = board[0][0];
  }
  
  if (board[0][2] !== '' &&
      board[0][2] === board[1][1] &&
      board[1][1] === board[2][0]) {
    winner = board[0][2];
  }
  
  return winner;
}

function isBoardFull() {
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (board[i][j] === '') {
        return false;
      }
    }
  }
  return true;
}


//jogo arvores

function initGame() {
  temperature = 30;
  gameStatus = 0;
  trees = [];
  grassPatches = Array.from({ length: 20 }, () => ({
    x: random(20, width - 20),
    y: random(20, height - 20),
    r: 20
  }));
}

//jogo camêra

class Objeto {
  constructor(x, y, img, nome) {
    this.x = x;
    this.y = y;
    this.img = img;
    this.nome = nome;
    this.fotografado = false;
  }

  display() {
    imageMode(CENTER);
    image(this.img, this.x, this.y, 50, 50);
  }
}
