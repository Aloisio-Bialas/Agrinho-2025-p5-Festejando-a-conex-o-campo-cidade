let liberar = 1;//permite mudar de cenários
let pontos = 0;//pontuação dos quizzis
//setas para passar e voltar cenários 
let SetaDireita;
let SetaEsquerda;
//cor dos quizzis----------------
let cor1Q1 = 140;
let cor2Q1 = 140;
let cor1Q2 = 140;
let cor2Q2 = 140;
let cor1Q3 = 140;
let cor2Q3 = 140;
let cor1Q4 = 140;
let cor2Q4 = 140;
let cor1Q5 = 140;
let cor2Q5 = 140;
let cor1Q6 = 140;
let cor2Q6 = 140;
let cor1Q7 = 140;
let cor2Q7 = 140;
//respostas dos quizzis -----------------
let resposta = 0;
let resposta2 = 0;
let resposta3Q = 0;
let resposta4Q = 0;
let resposta5Q = 0;
let resposta6Q = 0;
let resposta7 = 0
//funções dos quizzis---------------
let borda = 190;
let borda2 = 110;
let borda3 = 110;
let borda4 = 110;
let borda5 = 110;
let borda6 = 110;
let borda7 = 110;
let borda8 = 110;
let borda9 = 110;
let borda10 = 110;
let bordaJogosY = 50;
let bordaJogosX = 30;
let bordaJogosY2 = 125;
let bordaJogosX2 = 125;
//variáveis cenários-------------------
let jogos
let cenário = 1;
var INICIO;
var INICIO2;
var agrinho1;
var agrinho2;
var cenário6;
var cenário7;
var cenário8;
var cenário9;
var cenário10;
var cenário12;
var cenário13;
var cenário18;
let cenário20;
let cenário22;
let cenário23;
let cenário24;
let cenário25;
let cenário26;
let cenário27;
let cenário28;
let cenário29;
let cenário30;
let cenário31;
let cenário32;
let cenário33;
let JogoCaçaTesouro;
let campocidade;
let ExpJFotografia
let ExpJVelha
let ExpJMemória
let ExpJBolinha
let ExpJCaminhãozinho
let ExpJCaminhão
let ExpJTesouros
let ExpJReflorestamento
let PréJogos;
let Jogos35
//outras variáveis------------------------
let cards = [];            // Cartas
let cols = 4;              // Número de colunas
let rows = 3;              // Número de linhas
let cardW, cardH;          // Largura e altura de cada carta
let symbols = ['🚜','🏙','🎉','🍽','👗','🌾']; 
let flippedCards = [];     
let lock = false;          
let tesouros = [];
let totaltesouros = 8;
let foundCount = 0;
let truck;
let collectible;
let gridSize = 20;
let gameOver = false;
let collectibles = ["🌽", "🧀", "☕", "🎶", "🏙", "🎭", "🍽", "🚜"];
let balls = [];
let spawnInterval = 1000;
let lastSpawnTime = 0;
let score = 0;
let timeLimit = 90;
let startTime;
let gameEnded = false;
let gameWon = false;  
let fireworkParticles = [];
//cor background 
let c1, c2;
let lerpAmt = 0;
//variaveis outros jogos
let board;
let currentPlayer;
let gameOver3 = false;
let boardSize = 350;
let boardOffset = 25;
let imgX, imgO;
const REQUIRED_TREES = 25;
let grassPatches = [];
let trees = [];
let temperature = 30.0000;
let gameStatus;
//jogo fotografia
let cameraImg;
let objetos = [];
let fotosTiradas = 0;
let todosFotografados = false;
//jogo elementos que caem
let player;
let itens = [];
let pontos2 = 0;
let venceu = false;
let emojisCampoCidade = ['🌾', '🍅', '🥛', '📦', '🛒', '🏙️'];
//jogo abelha
let Abelha
let Flor1
let Flor2
let Flor3
let Flor4
let AbelhaX = 30
let AbelhaY = 300
let pontosAbelha = 0
//jogo corrida
let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let jogador = ["🌾", "🍅", "🥛", "🌽"];
let teclas = ["a", "s", "d", "f"];
let quantidade = jogador.length;
let vencedor = false

//carregar imagens------------------

function preload(){
  jogos = loadImage("cenário1.svg")
  INICIO = loadImage("cenário2.svg");
  INICIO2 = loadImage("cenário3..svg");
  agrinho1 = loadImage("cenário4..svg");
  agrinho2 = loadImage("cenário5..svg");
  cenário6 = loadImage("cenário6...svg");
  cenário7 = loadImage("cenário7.svg");
  cenário8 = loadImage("cenário8.svg");
  cenário9 = loadImage("cenário9.svg");
  cenário10 = loadImage("cenário10..svg");
  cenário12 = loadImage("cenário12..svg");
  cenário13 = loadImage("cenário13.svg");
  cenário15 = loadImage("cenário15.svg");
  cenário16 = loadImage("cenário16.svg");
  cenário18 = loadImage("cenário18.svg");
  cenário20 = loadImage("cenário20.svg");
  cenário22 = loadImage("cenário22.svg");
  cenário23 = loadImage("cenário23.svg");
  cenário24 = loadImage("cenário24.svg");
  cenário25 = loadImage("cenário25.svg");
  cenário26 = loadImage("cenário26.svg");
  cenário27 = loadImage("cenário27.svg");
  cenário28 = loadImage("cenário28.svg");
  cenário29 = loadImage("cenário29.svg");
  cenário30 = loadImage("cenário30.svg");
  cenário31 = loadImage("cenário31.svg");
  cenário32 = loadImage("cenário32.svg");
  cenário33 = loadImage("cenário33.svg");
  PréJogos = loadImage("PréJogos.svg");
  Jogos35 = loadImage("Jogos35.svg");
  JogoCaçaTesouro = loadImage("jogo caça ao tesouro.svg");
  Bemvindo = loadImage("Bem vindo.svg");
  imgX = loadImage("CidadeX.svg");
  imgO = loadImage("CampoO.svg");
  campocidade = loadImage("campo-cidade.svg");
  ExpJVelha = loadImage("Exp.J.Velha.svg");
  ExpJMemória = loadImage("Exp.J.Memória.svg");
  ExpJBolinha = loadImage("Exp.J.Bolinha.svg");
  SetaDireita = loadImage("SetaDireita.svg");
  SetaEsquerda = loadImage("SetaEsquerda.svg");
  cameraImg = loadImage("camera.svg");
  CenárioCamera = loadImage("CenárioCamera.svg");
  objetos.push(new Objeto(80, 150, loadImage("QuadradoCamera.svg"), "Trator"));
  objetos.push(new Objeto(200, 70, loadImage("QuadradoCamera.svg"), "Campo"));
  objetos.push(new Objeto(300, 250, loadImage("QuadradoCamera.svg"), "Cidade"));
  objetos.push(new Objeto(120, 320, loadImage("QuadradoCamera.svg"), "Antena de Internet"));
  objetos.push(new Objeto(350, 180, loadImage("QuadradoCamera.svg"), "Feira Rural"));
  ExpJCaminhãozinho = loadImage("Exp.J.Caminhãozinho.svg");
  ExpJCaminhão = loadImage("Exp.J.Caminhão.svg");
  ExpJTesouros = loadImage("Exp.J.Tesouros.svg");
  ExpJReflorestamento = loadImage("Exp.J.Reflorestamentp.svg");
  ExpJFotografia = loadImage("Exp.J.Foto.svg");
  Abelha = loadImage("Abelha.svg")
  Flor1 = loadImage("Flor.svg")
  
}

//------------------------------------------------

function setup() {
  createCanvas(400, 400);
  c1 = color(random(255), random(255), random(255));
  c2 = color(random(255), random(255), random(255));
  cardW = 80;
  cardH = 80; 
  let deck = symbols.concat(symbols);
  deck = shuffle(deck, true);
   let offsetX = (width - (cols * cardW)) / 2;
  let offsetY = (height - (rows * cardH)) / 2;
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      let index = i * cols + j;
      let card = {
        x: offsetX + j * cardW,
        y: offsetY + i * cardH,
        w: cardW,
        h: cardH,
        symbol: deck[index],
        flipped: false,
        matched: false
      };
      cards.push(card);
    }
  }
  let possibleEmojis = ["🎉", "🚜", "🌽", "🏙", "🍽", "🎶", "📚"];
  for (let i = 0; i < totaltesouros; i++) {
    let x = random(50, width - 100);
    let y = random(100, height - 100);
    let emoji = possibleEmojis[i % possibleEmojis.length];
    tesouros.push({
      x: x,
      y: y,
      emoji: emoji,
      found: false
    });
  }
  //caminhãozinho
  truck = new Truck();
  collectible = createCollectible();
  
  //jogo da velha
  
  board = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
  ];
  currentPlayer = "x";//define o jogador inicial cidade
  gameOver3 = false;
  
  //jogo camêra
  cameraX = 200
  cameraY = 200
  
  //jogo elementos que caem
  player = new Player();
  
}

function draw() {  
  if(cenário === 1){
  let bgColor = lerpColor(c1, c2, lerpAmt);
  background(bgColor);
  lerpAmt += 0.01;
  
  if (lerpAmt >= 1) {
    c1 = c2;
    c2 = color(random(255), random(255), random(255));
    lerpAmt = 0;
  }}else if(cenário !== 1){
    background("white")
  }
  
  
  //definições para cada cenário----------------
  
  if(cenário === 1){
    frameRate(60)
    image (Bemvindo, -5, 200, 420, 205)
  }
  if (cenário === 2) {
    background("red"); 
    image (INICIO, 0, 0, 400, 400)
    fill("yellow")
    textSize(12)
    text("Para prosseguir ou voltar os cenários use as setas na tela ou as setas do teclado." , 100, 5, 200)
  }
    if (cenário === 50){
    background("black"); 
    textSize(12)
      fill("yellow");
    text("Para voltar clique na seta da tela com o mouse ou pressione a seta do teclado.", 100, 5, 200)
  }
  if (cenário === 3) {
    image (INICIO2, 0, 0, 400, 400)
  }
  if (cenário === 4) {
    image (agrinho1, 0, 0, 400, 400)
  }
  if (cenário === 5) {
    image (agrinho2, 0, 0, 400, 400)
  }
  if (cenário === 6) {
    image (cenário6, 0, 0, 400, 400)
  }
  if (cenário === 7) {
    image (cenário7, 0, 0, 400, 400)
  }
  if (cenário === 8) {
    image (cenário8, 0, 0, 400, 400)
  }
  if (cenário === 9) {
    image (cenário9, 0, 0, 400, 400)
  }
  if (cenário === 10) {
    image (cenário10, 0, 0, 401, 400)
    liberar = 1
  }
  if (cenário === 11) {
    background("rgb(0,248,185)"); 
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    textSize(13)
    noStroke()
    fill("black");
    text("Agora que você sabe como a feira conecta o campo e a", 200, 70)
    text("cidade, marque a alternativa correta e ganhe pontos:", 200, 85)
    textSize(30)
    text("1:", 20, 80)
    fill(cor1Q1)
    rect(15, 110, 370, 60, 10)
    fill(cor2Q1)
    rect(15, 180, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    
      strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda2, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda2 - 2, 374, 64, 10);
  
  //perguntas:
    fill("black")
  noStroke()
    textSize(15)
  text("A feira propicia o intercâmbio entre agricultores e consumidores urbanos, fortalecendo a economia local.", 7, 125, 390)
    text("A feira é, praticamente, única um espaço de lazer, sem impacto na economia ou na relação campo/cidade.", 7, 195, 390)
    text("A feira serve somente para a venda de produtos industrializados, sem relação alguma com o campo.", 7, 265, 390)
    text("A feira não possibilita contato direto entre produtores e consumidores, não tendo relação entre campo e cidade.", 7, 335, 390)
}
  if (cenário === 12) {
    image (cenário12, 0, 0, 400, 400)
  }
  if (cenário === 13) {
    image (cenário13, 0, 0, 400, 400)
    liberar = 1
  }
  if (cenário === 14) {
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    
    
    textSize(13)
    noStroke()
    fill("black");
    text("Qual tecnologia no campo proporciona uma conexão entre", 200, 70)
    text("campo e cidade? Promovendo uma relação direta entre eles.", 200, 85)
    textSize(30)
    text("2:", 20, 80)
    fill(cor1Q2)
    rect(15, 110, 370, 60, 10)
    fill(cor2Q2)
    rect(15, 180, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda4, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda4 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(22)
    text("Drones de pulverização.", 7, 130, 390)
    text("Sensores de umidade no solo.", 7, 200, 390)
    text("Grandes máquinas agrícolas.", 7, 270, 390)
    text("Plataforma de vendas online.", 7, 340, 390)
}
  if (cenário === 15) {
    image (cenário15, 0, 0, 400, 400)
  }
  if (cenário === 16) {
    image (cenário16, 0, 0, 400, 400)
    liberar = 1;
  }
  if (cenário === 17) {
    resposta3 = 0;
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    
    
    textSize(13)
    noStroke()
    fill("black");
    text("Como festas típicas e celebrações proporcionam", 200, 70)
    text("uma conexão entre campo e cidade?", 200, 85)
    textSize(30)
    text("3:", 20, 80)
    fill(cor1Q3)
    rect(15, 180, 370, 60, 10)
    fill(cor2Q3)
    rect(15, 110, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda6, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda6 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("Únicamente promovendo competições desportivas entre residentes urbanos e rurais.", 7, 125, 390)
    text("Por meio da preservação cultural, do comércio de produtos provincianos e da interação social.", 7, 195, 370)
    text("Apenas através da exportação de produtos agrícolas para grandes centros urbanos.", 8, 265, 390)
    text("Apenas promovendo o turismo internacional em regiões rurais.", 8, 335, 380)
  }
  if (cenário === 18) {
    image (cenário18, 0, 0, 400, 400)
    liberar = 1
  }
  if (cenário === 19) {
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    
    
    textSize(13)
    noStroke()
    fill("black");
    text("Qual das alternativas a seguir apresenta um exemplo", 200, 70)
    text("de como a moda e os costumes rurais afetam a vida urbana?", 200, 85)
    textSize(30)
    text("4:", 20, 80)
    fill(cor1Q4)
    rect(15, 320, 370, 60, 10)
    fill(cor2Q4)
    rect(15, 180, 370, 60, 10)
    rect(15, 110, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda7, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda7 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("Só através do envio de produtos agrícolas dos centros rurais para os centros urbanos.", 8, 125, 370)
    text("Por meio da valorização das tradições rurais em roupas urbanas e da venda de produtos rurais", 10, 335, 370)
    text("Apenas pela absorção econômica da técnica agrícola nos locais urbanos.", 8, 265, 380)
    text("Somente pela criação de vestuário urbano em linha com as tendências internacionais.", 12, 195, 370)
  }
  if (cenário === 20) {
    image (cenário20, 0, 0, 400, 400)
    liberar = 1;
  }
  if (cenário === 21) {
    liberar = 2
    fill("yellow")
    strokeWeight(2)
    textSize(20)
    stroke("black")
    text("Hora de praticar: Acerte e ganhe pontos!" , 180, 50)
    
    
    textSize(13)
    noStroke()
    fill("black");
    text("Qual das alternativas a seguir apresenta um exemplo", 200, 70)
    text("de como a moda e os costumes rurais afetam a vida urbana?", 200, 85)
    textSize(30)
    text("5:", 20, 80)
    fill(cor2Q5)
    rect(15, 180, 370, 60, 10)
    rect(15, 110, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    fill(cor1Q5)
    rect(15, 250, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda8, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda8 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("Apenas pela troca de livros urbanos inspirados em tendências internacionais.", 7, 125, 370)
    text("Apenas por meio da troca de instrumentos musicais do campo por instrumentos da cidade.", 10, 195, 370)
    text("Por meio da valorização das tradições rurais na música e na literatura que atingem o público urbano.", 17, 265, 360)
    text("Apenas por meio da troca de estilos da música urbana por estilos da música rural.", 12, 335, 360)
  }
  if (cenário === 22) {
    image (cenário22, 0, 0, 400, 400)
  }
  if (cenário === 23) {
    image (cenário23, 0, 0, 400, 400)
  }
  if (cenário === 24) {
    image (cenário24, 0, 0, 400, 400)
  }
  if (cenário === 25) {
    image (cenário25, 0, 0, 400, 400)
  }
  if (cenário === 26) {
    image (cenário26, 0, 0, 402, 400)
  }
  if (cenário === 27) {
    image (cenário27, 0, 0, 400, 400)
  }
  if (cenário === 28) {
    image (cenário28, 0, 0, 400, 400)
    liberar = 1;
  }
  if (cenário === 29) {
    image (cenário29, 0, 0, 400, 400)
    liberar = 2;
    fill(cor1Q6)
    rect(15, 110, 370, 60, 10)
    fill(cor2Q6)
    rect(15, 180, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    rect(15, 320, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda9, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda9 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("As abelhas não são importantes, e poderiam ser extintas sem consequência alguma.", 11, 125, 370)
    text("Se as abelhas fossem extintas, o mundo acabaria em alguns anos, segundo Márcia d'Avila.", 10, 195, 370)
    text("As abelhas são polinizadoras essenciais para a biodiversidade e para a produção de alimentos.", 16, 265, 360)
    text("Segundo a (FAO), um terço da produção mundial de alimentos depende das abelhas.", 10, 335, 360)
  }
  if (cenário === 30) {
    image (cenário30, 0, 0, 402, 400)
  }
  if (cenário === 31) {
    image (cenário31, 0, 0, 400, 400)
  }
  if (cenário === 32) {
    image (cenário32, 0, 0, 400, 400)
    liberar = 1;
  }
  if (cenário === 33) {
    image (cenário33, 0, 0, 500, 500)
    liberar = 2;
    fill(cor2Q7)
    rect(15, 110, 370, 60, 10)
    rect(15, 180, 370, 60, 10)
    rect(15, 250, 370, 60, 10)
    fill(cor1Q7)
    rect(15, 320, 370, 60, 10)
    
    strokeWeight(3)
  noFill();
  stroke("rgb(255,0,0)");
  rect(15, borda10, 370, 60, 10);
    strokeWeight(2)
  noFill();
  stroke("black");
  rect(13, borda10 - 2, 374, 64, 10);
    
    fill("black")
  noStroke()
    textSize(15)
    text("A água é um dos principais elementos para a existência da vida humana.", 22, 125, 350)
    text("Quando o campo e a cidade trabalham juntos, há um aproveitamento de forma eficiente dos recursos hídricos.", 13, 195, 370)
    text("A água desempenha pepel fundamental tanto no campo como na cidade.", 20, 265, 360)
    text("Com a ausência de água, os meios rurais e urbanos não seriam afetados.", 20, 335, 360)
  }
  
  //empede que o jogador passe do cenário 35(jogos)
  
  if(cenário === 37 || cenário === 38 || cenário === 39 || cenário === 40 || cenário === 41 || cenário < 50 && cenário > 36){
    cenário = 35
  }
  
    //empede que o jogador volte mais que o cenário 1(introdução)
  
  if(cenário === -1 || cenário === -2 || cenário === -3 || cenário === -4 || cenário === -5 || cenário === -6 || cenário < -6){
    cenário = 1
  }
  
  //pré jogos
  
  if(cenário === 34){
    image(PréJogos, 0, 0, 400, 400)
  }
  
  //EXPLIÇÃO JOGOS---------------------------------------
  
  if (cenário === 1001) {
    imageMode(CORNER);
    image (ExpJFotografia, 0, 0, 400, 400)
  }
  if (cenário === 1002) {
    image (ExpJVelha, 0, 0, 400, 400)
  }
  if (cenário === 1003) {
    image (ExpJMemória, 0, 0, 400, 400)
    strokeWeight(1)
    textSize(22)
    text("A seguir, os elementos presente no jogo:", 200, 260)
    textSize(25)
    text("🚜  🏙  🎉  🍽  👗  🌾", 200, 300)
  }
  if (cenário === 1004) {
    image (ExpJBolinha, 0, 0, 400, 400)
  }
  if (cenário === 1005) {
   telaExplicacao();
  }
  if (cenário === 1006) {
    image(ExpJCaminhãozinho, 0, 0, 400, 400)
  }
  if (cenário === 1007) {
    image (ExpJCaminhão, 0, 0, 400, 400)
  }
  if (cenário === 1008) {
    image (ExpJTesouros, 0, 0, 400, 400)
  }
  if (cenário === 1009) {
    image (ExpJReflorestamento, 0, 0, 400, 400)
  }
  if(cenário === 1010) {

  }
  
  //opções de jogos--------------------------------------
  if(cenário === 35){
    
    image(jogos, 0, 0, 400, 400)
    
    //borda para excolher jogo com mouse
    if(mouseX > 30 && mouseX < 130 && mouseY > 50 && mouseY < 120){
    bordaJogosX = 30 
    bordaJogosY = 50
    }//jogo foto
    
    if(mouseX > 150 && mouseX < 250 && mouseY > 50 && mouseY < 120){
    bordaJogosX = 150 
    bordaJogosY = 50
    }//jogo velha
    
    if(mouseX > 270 && mouseX < 370 && mouseY > 50 && mouseY < 120){
    bordaJogosX = 270 
    bordaJogosY = 50
    }//jogo memória
    
    if(mouseX > 30 && mouseX < 130 && mouseY > 170 && mouseY < 240){
    bordaJogosX = 30 
    bordaJogosY = 170
    }//jogo bolinha
    
    if(mouseX > 150 && mouseX < 250 && mouseY > 170 && mouseY < 240){
    bordaJogosX = 150 
    bordaJogosY = 170
    }//jogo elementos caem
    
    if(mouseX > 270 && mouseX < 370 && mouseY > 170 && mouseY < 240){
    bordaJogosX = 270 
    bordaJogosY = 170
    }//jogo caminhãozinho
    
    if(mouseX > 30 && mouseX < 130 && mouseY > 290 && mouseY < 360){
    bordaJogosX = 30 
    bordaJogosY = 290
    }//jogo caminhão
    
    if(mouseX > 150 && mouseX < 250 && mouseY > 290 && mouseY < 360){
    bordaJogosX = 150 
    bordaJogosY = 290
    }//jogo elementos culturais
    
    if(mouseX > 270 && mouseX < 370 && mouseY > 290 && mouseY < 360){
    bordaJogosX = 270 
    bordaJogosY = 290
    }//jogo reflorestamento
    
    imageMode(CORNER);
    image(Jogos35, 0, 0, 400, 400)
    noStroke()
    fill("blue")
     rect(30, 50, 100, 70, 10)
     rect(150, 50, 100, 70, 10)
     rect(270, 50, 100, 70, 10)
     rect(30, 170, 100, 70, 10)
     rect(150, 170, 100, 70, 10)
     rect(270, 170, 100, 70, 10)
     rect(30, 290, 100, 70, 10)
     rect(150, 290, 100, 70, 10)
     rect(270, 290, 100, 70, 10)
    
    //borda------------
    stroke("black")
    strokeWeight(3)
    noFill()
    rect(bordaJogosX, bordaJogosY, 100, 70, 10)
     }
  
  if(cenário === 101){
    imageMode(CORNER);
    image(CenárioCamera, 0, 0, 400, 400)
    // Exibir objetos com suas imagens
  for (let obj of objetos) {
    obj.display();
  }

  // Exibir câmera como imagem;
  image(cameraImg, cameraX, cameraY, 50, 50);

  // Exibir mensagem se todos foram fotografados
  if (todosFotografados) {
    fill(0, 255, 0);
    textSize(20);
    textAlign(CENTER);
    text("Todos os elementos foram fotografados!", width / 2, height / 2);
  }
  }
  
  if(cenário === 103){
    for (let card of cards) {
    drawCard(card);
  }

  if (cards.every(card => card.matched)) {
    fill(0, 150);
    rect(0, 0, width, height);
    fill(255);
    textSize(20);
    text("Parabéns! Você uniu o Campo e a Cidade!", width / 2, height / 2);
  }
  }
  
  if(cenário === 108){
    image(JogoCaçaTesouro, 0, 0, 403, 420)
  textSize(18);
  for (let t of tesouros) {
    if (t.found) {
      fill(255, 255, 255, 255);
      text(t.emoji, t.x, t.y);
    } else {
      fill(255, 255, 255, 70);
      text(t.emoji, t.x, t.y);
    }
  }
    fill(0);
  textSize(20);
    noStroke()
  text("Caça ao Tesouro Cultural", width / 2, 30);
  text("Tesouros encontrados: " + foundCount + " / " + totaltesouros, width / 2, 60);
    
    if (foundCount === totaltesouros) {
    fill(0, 150);
    rect(0, 0, width, height);
    fill(255);
    textSize(19);
    text("Parabéns! Você achou todos os tesouros culturais!", width / 2, height / 2);
  }
}
  if(cenário === 106){
    frameRate(6)
    if (gameOver) {
      cenário = 10000
  }

  truck.update();
  truck.show();

  textSize(24);
  fill(255);
  textAlign(CENTER, CENTER);
  text(collectible.item, collectible.x + gridSize / 2, collectible.y + gridSize / 2);

  if (truck.collect(collectible)) {
    collectible = createCollectible();
  }

  if (truck.checkCollision() || truck.hitWall()) {
    gameOver = true;
  }
}
  if(cenário === 10000){//gameover cobrinha
    textSize(32);
    fill(255);
    textAlign(CENTER, CENTER);
    text("Game Over!", width / 2, height / 2);
    textSize(20);
    text("Pressione ENTER para reiniciar", width / 2, height / 2 + 40);
  }
  
  if(cenário === 104){
    image(campocidade, -5, 255, 420, 150)
    frameRate(50)
    let elapsed = (millis() - startTime) / 1000;

  if (!gameEnded) {
    // Gera novas bolinhas se o intervalo tiver passado
    if (millis() - lastSpawnTime > spawnInterval) {
      spawnBall();
      lastSpawnTime = millis();
    }
    
    // Atualiza e exibe cada bolinha
    for (let i = balls.length - 1; i >= 0; i--) {
      let b = balls[i];
      b.update();
      b.display();
      
      // Remove a bolinha se ela sair da tela (abaixo)
      if (b.y - b.radius > height) {
        balls.splice(i, 1);
      }
    }
    
    // Exibe a pontuação e o tempo restante (canto superior esquerdo)
    textSize(15)
    fill(0);
    noStroke(2);
    textAlign(CENTER, CENTER)
    text("Pontuação: " + score, 60, 20);
    
    // Verifica condições de fim de jogo
    if (score >= 500) {
      gameWon = true;
      gameEnded = true;
    }
  }
  
  // Se o jogo terminou, exibe a tela final
  if (gameEnded) {
    if (gameWon) {
      // Se os fogos de artifício ainda não foram gerados, gera-os
      if (fireworkParticles.length === 0) {
        spawnFireworks();
      }
      // Atualiza e exibe os fogos de artifício
      for (let i = fireworkParticles.length - 1; i >= 0; i--) {
        let p = fireworkParticles[i];
        p.update();
        p.display();
        if (p.life <= 0) {
          fireworkParticles.splice(i, 1);
        }
      }
      // Tela de vitória
      fill(0, 200);
      rect(0, 0, width, height);
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(28);
      text("Você ganhou!\nPontuação: " + score, width / 2, height / 2);
    } 
  }
}
  
  if(cenário === 102){
    
    strokeWeight(0)
    textSize(12)
  text("Em caso de empate ou se você quiser reiniciar o jogo clique ENTER.", 200, 395)
    
    if(currentPlayer === "x"){
      strokeWeight(1)
      textSize(15)
      fill(0)
      text("Jogador Atual: Cidade", 200, 16)
    } else if(currentPlayer === "o"){
      strokeWeight(1)
      fill(0)
      textSize(15)
     text("Jogador Atual: Campo", 200, 16)
    }
    
      drawBoard();
    gameOver3 = false;
    
    let winner = checkWinner();
  if (winner) {
    fill(255)
    rect(0, 0, 400, 400)
    gameOver3 = true;
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    strokeWeight(2)
    text("Vencedor: ", 144, 80);
    textSize(25)
    text("Pressione ENTER para reiniciar", 200, 300)
    // Exibe a imagem do jogador vencedor centralizada
    if (winner === "x") {
      text("Cidade", 260, 80)
      image(imgX, width / 2 - boardSize/6, height / 2 - boardSize/6, boardSize/3, boardSize/3);
    } else {
      text("Campo", 260, 80)
      image(imgO, width / 2 - boardSize/6, height / 2 - boardSize/6, boardSize/3, boardSize/3);
    }
  } else if (isBoardFull()) {
    gameOver3 = true;
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text("Empate!", width / 2, 150, 200);
  }
  }
  
  if(cenário === 109){
noStroke();
  fill(100, 200, 100);
  grassPatches.forEach(g => ellipse(g.x, g.y, g.r * 2));

  // desenha árvores plantadas
  trees.forEach(t => {
    fill(139, 69, 19);        // tronco
    rect(t.x - 5, t.y, 10, 20);
    fill(34, 139, 34);        // copa
    ellipse(t.x, t.y, 30);
  });

  // atualiza temperatura e verifica condições de fim de jogo
  if (gameStatus === 0) {
    temperature += (deltaTime / 1000) * 0.5;
    if (temperature >= 45) gameStatus = -1;
    if (trees.length >= REQUIRED_TREES) gameStatus = 1;
  }

  // HUD
  fill(0);
  textSize(20);
  textAlign(CENTER, CENTER);
  text("Temperatura" + temperature.toFixed(1), 60, 20);
  text(`Árvores: ${trees.length}/${REQUIRED_TREES}`, 60, 45);

  // tela de vitória ou derrota
  if (gameStatus !== 0) {
    textAlign(CENTER, CENTER);
    textSize(36);
    if (gameStatus === 1) {
      fill(0, 150, 0);
      text("Você Ganhou!", width / 2, height / 2 - 20);
    } else {
      fill(150, 0, 0);
      text("Você Perdeu!", width / 2, height / 2 - 20);
    }
    textSize(20);
    fill(0);
    text("Pressione ENTER para reiniciar", width / 2, height / 2 + 20);
  }
  }
  
  if (cenário === 105) {
     frameRate(30)
    jogar();
  }
  
  if(cenário === 107){
    ativaJogo();
  desenhaJogadores();
  desenhaLinhaDeChegada();
  verificaVencedor();
  }
  
  
  //interface de jogos 2
  
  if(cenário === 36){
    
    image(Jogos35, 0, 0, 400, 400)
    noStroke()
    fill("blue")
    rect(125, 125, 150, 150, 10)
    
    stroke("black")
    strokeWeight(3)
    noFill()
    rect(bordaJogosX2, bordaJogosY2, 150, 150, 10)
    
    //borda para excolher jogo com mouse na segunda parte
    if(mouseX > 70 && mouseX < 170 && mouseY > 70 && mouseY < 170){
    bordaJogosX2 = 125 
    bordaJogosY2 = 125
    }
  }
  
  if(cenário === 110){
    textSize(15)
    fill(0)
    strokeWeight(1)
    text("pontos:" + pontosAbelha, 200, 20)
    if(pontosAbelha !== 5){
    image(Abelha, AbelhaX, AbelhaY, 50, 50)
    }
    if(pontosAbelha === 0){
    image(Flor1, 300, 50, 30, 30)
    }
    if(pontosAbelha === 1){
    image(Flor1, 40, 50, 30, 30)
    }
    if(pontosAbelha === 2){
    image(Flor1, 100, 280, 30, 30)
    }
    if(pontosAbelha === 3){
    image(Flor1, 200, 200, 30, 30)
    }
    if(pontosAbelha === 4){
    image(Flor1, 350, 350, 30, 30)
    }
    
    if(AbelhaX > 250 && AbelhaX < 360 && AbelhaY > 20 && AbelhaY < 110 && pontosAbelha === 0){
      pontosAbelha = 1
    }
    if(AbelhaX > 10 && AbelhaX < 80 && AbelhaY > 20 && AbelhaY < 110 && pontosAbelha === 1){
      pontosAbelha = 2
    }
    if(AbelhaX > 80 && AbelhaX < 150 && AbelhaY > 250 && AbelhaY < 330 && pontosAbelha === 2){
      pontosAbelha = 3
    }
    if(AbelhaX > 170 && AbelhaX < 230 && AbelhaY > 170 && AbelhaY < 230 && pontosAbelha === 3){
      pontosAbelha = 4
    }
    if(AbelhaX > 320 && AbelhaX < 380 && AbelhaY > 320 && AbelhaY < 380 && pontosAbelha === 4){
      pontosAbelha = 5
    }
    if(pontosAbelha === 5){
      textSize(20)
      text("Parabéns, você polinizou o campo e a cidade!", 200, 200)
      textSize(15)
      text("Pressione ENTER para reiniciar!", 200, 230)
      image(Abelha, 160, 260, 160, 130)
    }
  }
  
 //ínicio e botões---------------------------------
  if (cenário === 1){
if (mouseX >= 100 && mouseX <= 300 && mouseY >= 190 && mouseY <= 240) {
    borda = 190;
  } else if(mouseX >= 100 && mouseX <= 300 && mouseY >= 290 && mouseY <= 340){
    borda = 290;
  }
  noStroke();
  fill("black");
  rect(100, 200, 200, 50, 20);
  rect(100, 300, 200, 50, 20);
  fill("blue");
  rect(100, 190, 200, 50, 20);
  rect(100, 290, 200, 50, 20);//desenha rect para formular botões
  
  strokeWeight(3)
  noFill();
  stroke(220, 220, 220);
  rect(100, borda, 200, 50, 20);
  
  noStroke();
  fill("black");
  textFont('Arial');
  textSize(30);
  textAlign(CENTER);
  text("Play", 200, 225);
  text("Explicações", 200, 325);
  textSize(50)
  stroke(0)
  strokeWeight(2);
  fill("yellow")
  text("BEM VINDO!", 200, 70)
  textSize(20)
  textFont('Oswald')
  text('Festejando a conexão CAMPO CIDADE', 200, 150)
  text('AGRINHO 2025', 200, 110)
  noStroke()
  fill("white")
  textSize(12)
  text("Use as setas do teclado e ENTER e/ou o mouse para selecionar o botão.", 200, 395)
  }
  
//demais códigos--------------------------------------
  
  //código setas exp jogos 
  
  if(cenário !== 1 && cenário !== 34 && cenário !== 50 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109 && cenário !== 110 && cenário !== 36){
  image(SetaDireita, 355, 5, 40, 20)}
    if(cenário !== 1 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109 && cenário !== 110){
  image(SetaEsquerda, 5, 5, 40, 20)
  }
    
  //Texto que aparece em baixo de todos os quizzis
  
  if(cenário === 11 || cenário === 14 || cenário === 17 || cenário === 19 || cenário === 21 || cenário === 29 || cenário === 33){
    fill(0)
  textSize(12)
  text("Use o mouse para selecionar a resposta desejada.", 200, 395)
  }
  
  //códigos bordas quizzis pelo mouse
      if(mouseX >= 15 && mouseX <= 385 && mouseY >= 110 && mouseY <= 170){ 
      if(cenário === 11 && resposta !== 1 && resposta !== 2){
        borda2 = 110
      }//quizz1
        
    else if(cenário === 14 && resposta2 !== 1 && resposta2 !== 2){
        borda4 = 110
      }//quizz2
        
    else if(cenário === 17 && resposta3Q !== 1 && resposta3Q !== 2){
        borda6 = 110
      }//quizz3
        
    else if(cenário === 19 && resposta4Q !== 1 && resposta4Q !== 2){
        borda7 = 110
      }//quizz4
        
        else if(cenário === 21 && resposta5Q !== 1 && resposta5Q !== 2){
        borda8 = 110
      }//quizz5
        
        else if(cenário === 29 && resposta6Q !== 1 && resposta6Q !== 2){
        borda9 = 110
      }//quizz6
        
        else if(cenário === 33 && resposta7 !== 1 && resposta7 !== 2){
        borda10 = 110
      }//quizz7
  }
  
  if(mouseX >= 15 && mouseX <= 385 && mouseY >= 180 && mouseY <= 240){
      if(cenário === 11 && resposta !== 1 && resposta !== 2){
        borda2 = 180
    }//quizz1
    
    else if(cenário === 14 && resposta2 !== 1 && resposta2 !== 2){
        borda4 = 180
      }//quizz2
    
    else if(cenário === 17 && resposta3Q !== 1 && resposta3Q !== 2){
        borda6 = 180
      }//quizz3
    
    else if(cenário === 19 && resposta4Q !== 1 && resposta4Q !== 2){
        borda7 = 180
      }//quizz4
    
    else if(cenário === 21 && resposta5Q !== 1 && resposta5Q !== 2){
        borda8 = 180
      }//quizz5
    
    else if(cenário === 29 && resposta6Q !== 1 && resposta6Q !== 2){
        borda9 = 180
      }//quizz6
    
    else if(cenário === 33 && resposta7 !== 1 && resposta7 !== 2){
        borda10 = 180
      }//quizz7
  }
  
  if(mouseX >= 15 && mouseX <= 385 && mouseY >= 250 && mouseY <= 310){
      if(cenário === 11 && resposta !== 1 && resposta !== 2){
        borda2 = 250//quizz1
      }
    
    else if(cenário === 14 && resposta2 !== 1 && resposta2 !== 2){
        borda4 = 250
      }//quizz2
    
    else if(cenário === 17 && resposta3Q !== 1 && resposta3Q !== 2){
        borda6 = 250
      }//quizz3
    
    else if(cenário === 19 && resposta4Q !== 1 && resposta4Q !== 2){
        borda7 = 250
      }//quizz4
    
    else if(cenário === 21 && resposta5Q !== 1 && resposta5Q !== 2){
        borda8 = 250
      }//quizz5
    
    else if(cenário === 29 && resposta6Q !== 1 && resposta6Q !== 2){
        borda9 = 250
      }//quizz6
    
    else if(cenário === 33 && resposta7 !== 1 && resposta7 !== 2){
        borda10 = 250
      }//quizz7
  }
  
  if(mouseX >= 15 && mouseX <= 385 && mouseY >= 320 && mouseY <= 380){
      if(cenário === 11 && resposta !== 1 && resposta !== 2){
        borda2 = 320
      }//quizz1
    
    else if(cenário === 14 && resposta2 !== 1 && resposta2 !== 2){
        borda4 = 320
      }//quizz2
    
    else if(cenário === 17 && resposta3Q !== 1 && resposta3Q !== 2){
        borda6 = 320
      }//quizz3
    
    else if(cenário === 19 && resposta4Q !== 1 && resposta4Q !== 2){
        borda7 = 320
      }//quizz4
    
    else if(cenário === 21 && resposta5Q !== 1 && resposta5Q !== 2){
        borda8 = 320
      }//quizz5
    
    else if(cenário === 29 && resposta6Q !== 1 && resposta6Q !== 2){
        borda9 = 320
      }//quizz6
    
    else if(cenário === 33 && resposta7 !== 1 && resposta7 !== 2){
        borda10 = 320
      }//quizz7
  }
  
   //outros códigos quizz1
  if(cenário === 11){
    liberar = 2
  if (resposta === 1){
    borda2 = 110
    liberar = 1
    strokeWeight(1)
    textSize(15)
    stroke("black")
    fill("green");
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  } else if (resposta === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  }
  }
  
  //outros códigos quizz2
  if(cenário === 14){
    liberar = 2
  if (resposta2 === 1){
    borda4 = 110
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  } else if (resposta2 === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  }
  }
  
  //outros códigos quizz3
  if(cenário === 17){
    liberar = 2
  if (resposta3Q === 1){
    borda6 = 180
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  } else if (resposta3Q === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  }
  }
  
  //outros códigos quizz4
  if(cenário === 19){
    liberar = 2
  if (resposta4Q === 1){
    borda7 = 320
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  } else if (resposta4Q === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103)
    text(pontos, 310, 103)
  }
  }
  
  //outros códigos quizz5
  if(cenário === 21){
    liberar = 2
  if (resposta5Q === 1){
    borda8 = 250
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
    if (resposta5Q === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
  }
  
  //outros códigos quizz6
  if(cenário === 29){
    liberar = 2
  if (resposta6Q === 1){
    borda9 = 110
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
    if (resposta6Q === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
  }
  
  //outros códigos quizz7
  if(cenário === 33){
    liberar = 2
  if (resposta7 === 1){
    borda10 = 320
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("green");
    textSize(15)
    text("você acertou! + 10 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
    if (resposta7 === 2){
    liberar = 1
    strokeWeight(1)
    stroke("black")
    fill("red");
    textSize(15)
    text("você errou! + 0 pontos       pontos atuais:", 160, 103);
    text(pontos, 310, 103);
  }
  }
  
  //carregando----------------------------------------
  
  
//----------------------------------------------------
}
  
//função para teclas----------------------------------

function keyPressed() {
  if (keyCode === 27 && cenário === 101){cenário = 1001}
  if (keyCode === 27 && cenário === 102){cenário = 1002}
  if (keyCode === 27 && cenário === 103){cenário = 1003}
  if (keyCode === 27 && cenário === 104){cenário = 1004}
  if (keyCode === 27 && cenário === 105){cenário = 1005}
  if (keyCode === 27 && cenário === 106){cenário = 1006}
  if (keyCode === 27 && cenário === 107){cenário = 1007}
  if (keyCode === 27 && cenário === 108){cenário = 1008}
  if (keyCode === 27 && cenário === 109){cenário = 1009}
  if (keyCode === 27 && cenário === 110){cenário = 1010}

    //--------------------------------------------------
  
  //teclas jogo caminhãozinho---------------------
  
  if(cenário === 106){
    
  if (keyCode === UP_ARROW && truck.ydir === 0) {
    truck.setDirection(0, -1);
  } else if (keyCode === DOWN_ARROW && truck.ydir === 0) {
    truck.setDirection(0, 1);
  } else if (keyCode === LEFT_ARROW && truck.xdir === 0) {
    truck.setDirection(-1, 0);
  } else if (keyCode === RIGHT_ARROW && truck.xdir === 0) {
    truck.setDirection(1, 0);
  } 
  }
       
    if (keyCode === ENTER && gameOver && cenário === 10000) {
    cenário = 106
    restartGame();
    }
      
  //jogo arvore
  
  if (keyCode === ENTER && gameStatus !== 0 && cenário === 109) {
    initGame();
  }
  if (keyCode === ENTER && cenário === 102) {
    gameOver3 = false;
    board = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
  ];
  }
  
  
  //jogo camera
  
  if(cenário === 101){
    if(todosFotografados === false){
  if (keyCode === LEFT_ARROW && cameraX > 20) cameraX -= 20;
  if (keyCode === RIGHT_ARROW && cameraX < 370) cameraX += 20;
  if (keyCode === UP_ARROW && cameraY > 20) cameraY -= 20;
  if (keyCode === DOWN_ARROW && cameraY < 370) cameraY += 20;
    }

  // Simular captura da foto
  
  if (key === ' ') {
    for (let obj of objetos) {
      if (!obj.fotografado && dist(cameraX, cameraY, obj.x, obj.y) < 50) {
        obj.fotografado = true;
        fotosTiradas++;
        console.log("Foto tirada de: " + obj.nome);
      }
    }
    
    // Verifica se todos foram fotografados
    if (fotosTiradas === objetos.length) {
      todosFotografados = true;
    }
  }
  }
  
  //funções jogo elementos que caem
  
  if (cenário === 1005 && keyCode === RIGHT_ARROW) {
    cenário = 105;
    pontos2 = 0;
    itens = [];
    venceu = false;
    loop();
  } else if (cenário === 105 && keyCode === ESCAPE) {
    cenário = 1005;
    loop();
  } else if (cenário === 105 && venceu && keyCode === ENTER) {
    pontos2 = 0;
    itens = [];
    venceu = false;
    loop();
  }
  
  //funções jogo Abelha
  if(cenário === 110 && pontosAbelha !== 5){
  if(keyCode === LEFT_ARROW){
    AbelhaX -= 20
  }
  if(keyCode === RIGHT_ARROW){
    AbelhaX += 20
  }
  if(keyCode === UP_ARROW){
    AbelhaY -= 20
  }
  if(keyCode === DOWN_ARROW){
    AbelhaY += 20
  }
  }
    if(keyCode === ENTER){
      pontosAbelha = 0
      AbelhaX = 30
      AbelhaY = 300   
    }

}

//jogo da memória----------------------------
function drawCard(card) {
  stroke(0);
  strokeWeight(2);
  // Se a carta está virada ou já combinada, mostra o símbolo
  if (card.flipped || card.matched) {
    fill(255);
    rect(card.x, card.y, card.w, card.h, 10);
    textSize(32);
    fill(0);
    text(card.symbol, card.x + card.w / 2, card.y + card.h / 2);
  } 
  else {
    // Carta com verso (oculta)
    fill(100);
    rect(card.x, card.y, card.w, card.h, 10);
  }
}
// ------------------------------------------

function mousePressed() {
  //resposta dos quizzis pelo mouse 
  if(mouseX >= 15 && mouseX <= 385 && mouseY >= 110 && mouseY <= 170){ 
      if(cenário === 11 && resposta !== 1 && resposta !== 2){
        borda2 = 110
        resposta = 1
        cor1Q1= "green"
      }//quizz1
        
    else if(cenário === 14 && resposta2 !== 1 && resposta2 !== 2){
      borda4 = 110
        resposta2 = 1
      cor1Q2= "green"
      }//quizz2
        
    else if(cenário === 17 && resposta3Q !== 1 && resposta3Q !== 2){
      borda6 = 110
        resposta3Q = 2
      cor2Q3 = "red"
    cor1Q3= "green"
      }//quizz3
        
    else if(cenário === 19 && resposta4Q !== 1 && resposta4Q !== 2){
      borda7 = 110
        resposta4Q = 2
      cor2Q4 = "red"
    cor1Q4= "green"
      }//quizz4
        
        else if(cenário === 21 && resposta5Q !== 1 && resposta5Q !== 2){
          borda8 = 110
        resposta5Q = 2
          cor2Q5 = "red"
    cor1Q5= "green"
      }//quizz5
        
        else if(cenário === 29 && resposta6Q !== 1 && resposta6Q !== 2){
          borda9 = 110
        resposta6Q = 1
          cor1Q6= "green"
      }//quizz6
        
        else if(cenário === 33 && resposta7 !== 1 && resposta7 !== 2){
          borda10 = 110
        resposta7 = 2
          cor2Q7 = "red"
    cor1Q7= "green"
      }//quizz7
  }
  if(mouseX >= 15 && mouseX <= 385 && mouseY >= 180 && mouseY <= 240){
      if(cenário === 11 && resposta !== 1 && resposta !== 2){
        borda2 = 180
        resposta = 2
        cor2Q1 = "red"
    cor1Q1= "green"
    }//quizz1
    
    else if(cenário === 14 && resposta2 !== 1 && resposta2 !== 2){
      borda4 = 180
       resposta2 = 2
      cor2Q2 = "red"
    cor1Q2= "green"
      }//quizz2
    
    else if(cenário === 17 && resposta3Q !== 1 && resposta3Q !== 2){
      borda6 = 180
        resposta3Q = 1
      cor1Q3= "green"
      }//quizz3
    
    else if(cenário === 19 && resposta4Q !== 1 && resposta4Q !== 2){
      borda7 = 180
        resposta4Q = 2
      cor2Q4 = "red"
    cor1Q4= "green"
      }//quizz4
    
    else if(cenário === 21 && resposta5Q !== 1 && resposta5Q !== 2){
      borda8 = 180
        resposta5Q = 2
      cor2Q5 = "red"
    cor1Q5= "green"
      }//quizz5
    
    else if(cenário === 29 && resposta6Q !== 1 && resposta6Q !== 2){
      borda9 = 180
        resposta6Q = 2
      cor2Q6 = "red"
    cor1Q6= "green"
      }//quizz6
    
    else if(cenário === 33 && resposta7 !== 1 && resposta7 !== 2){
      borda10 = 180
        resposta7 = 2
      cor2Q7 = "red"
    cor1Q7= "green"
      }//quizz7
  }
  
  if(mouseX >= 15 && mouseX <= 385 && mouseY >= 250 && mouseY <= 310){
      if(cenário === 11 && resposta !== 1 && resposta !== 2){
        borda2 = 250
       resposta = 2
        cor2Q1 = "red"
    cor1Q1= "green"//quizz1
      }
    
    else if(cenário === 14 && resposta2 !== 1 && resposta2 !== 2){
      borda4 = 250
        resposta2 = 2
      cor2Q2 = "red"
    cor1Q2= "green"
      }//quizz2
    
    else if(cenário === 17 && resposta3Q !== 1 && resposta3Q !== 2){
      borda6 = 250
        resposta3Q = 2
      cor2Q3 = "red"
    cor1Q3= "green"
      }//quizz3
    
    else if(cenário === 19 && resposta4Q !== 1 && resposta4Q !== 2){
      borda7 = 250
        resposta4Q = 2
      cor2Q4 = "red"
    cor1Q4= "green"
      }//quizz4
    
    else if(cenário === 21 && resposta5Q !== 1 && resposta5Q !== 2){
      borda8 = 250
        resposta5Q = 1
      cor1Q5= "green"
      }//quizz5
    
    else if(cenário === 29 && resposta6Q !== 1 && resposta6Q !== 2){
      borda9 = 250
        resposta6Q = 2
      cor2Q6 = "red"
    cor1Q6= "green"
      }//quizz6
    
    else if(cenário === 33 && resposta7 !== 1 && resposta7 !== 2){
      borda10 = 250
        resposta7 = 2
      cor2Q7 = "red"
    cor1Q7= "green"
      }//quizz7
  }
  
  if(mouseX >= 15 && mouseX <= 385 && mouseY >= 320 && mouseY <= 380){
      if(cenário === 11 && resposta !== 1 && resposta !== 2){
        borda2 = 320
        resposta = 2
        cor2Q1 = "red"
    cor1Q7= "green"
      }//quizz1
    
    else if(cenário === 14 && resposta2 !== 1 && resposta2 !== 2){
      borda4 = 320
        resposta2 = 2
      cor2Q2 = "red"
    cor1Q2= "green"
      }//quizz2
    
    else if(cenário === 17 && resposta3Q !== 1 && resposta3Q !== 2){
      borda6 = 320
        resposta3Q = 2
      cor2Q3 = "red"
    cor1Q3= "green"
      }//quizz3
    
    else if(cenário === 19 && resposta4Q !== 1 && resposta4Q !== 2){
      borda7 = 320
        resposta4Q = 1
      cor1Q4= "green"
      }//quizz4
    
    else if(cenário === 21 && resposta5Q !== 1 && resposta5Q !== 2){
      borda8 = 320
        resposta5Q = 2
      cor2Q5 = "red"
    cor1Q5= "green"
      }//quizz5
    
    else if(cenário === 29 && resposta6Q !== 1 && resposta6Q !== 2){
      borda9 = 320
        resposta6Q = 2
      cor2Q6 = "red"
    cor1Q6= "green"
      }//quizz6
    
    else if(cenário === 33 && resposta7 !== 1 && resposta7 !== 2){
      borda10 = 320
       resposta7 = 1
    cor1Q7= "green"
      }//quizz7
  }
  
  //escolher jogos com o mouse 
  
  if(cenário === 35){
    if(mouseX > 30 && mouseX < 130 && mouseY > 50 && mouseY < 120){
    bordaJogosX = 30 
    bordaJogosY = 50
      cenário = 1001
    }//jogo foto
    
    if(mouseX > 150 && mouseX < 250 && mouseY > 50 && mouseY < 120){
    bordaJogosX = 150 
    bordaJogosY = 50
      cenário = 1002
    }//jogo velha
    
    if(mouseX > 270 && mouseX < 370 && mouseY > 50 && mouseY < 120){
    bordaJogosX = 270 
    bordaJogosY = 50
      cenário = 1003
    }//jogo memória
    
    if(mouseX > 30 && mouseX < 130 && mouseY > 170 && mouseY < 240){
    bordaJogosX = 30 
    bordaJogosY = 170
      cenário = 1004
    }//jogo bolinha
    
    if(mouseX > 150 && mouseX < 250 && mouseY > 170 && mouseY < 240){
    bordaJogosX = 150 
    bordaJogosY = 170
      cenário = 1005
    }//jogo elementos caem
    
    if(mouseX > 270 && mouseX < 370 && mouseY > 170 && mouseY < 240){
    bordaJogosX = 270 
    bordaJogosY = 170
      cenário = 1006
    }//jogo caminhãozinho
    
    if(mouseX > 30 && mouseX < 130 && mouseY > 290 && mouseY < 360){
    bordaJogosX = 30 
    bordaJogosY = 290
      cenário = 1007
    }//jogo caminhão
    
    if(mouseX > 150 && mouseX < 250 && mouseY > 290 && mouseY < 360){
    bordaJogosX = 150 
    bordaJogosY = 290
      cenário = 1008
    }//jogo elementos culturais
    
    if(mouseX > 270 && mouseX < 370 && mouseY > 290 && mouseY < 360){
    bordaJogosX = 270 
    bordaJogosY = 290
      cenário = 1009
    }//jogo reflorestamento
  }
  //tela jogos 2
  
  //borda para excolher jogo com mouse na segunda parte
  if(cenário === 36){
    if(mouseX > 125 && mouseX < 275 && mouseY > 125 && mouseY < 275){
    bordaJogosX2 = 125 
    bordaJogosY2 = 125
      cenário = 1010
    }
}
  
  //botões da tela inicial pelo mouse
  if (cenário === 1){
if (mouseX >= 100 && mouseX <= 300 && mouseY >= 190 && mouseY <= 240 && borda === 190) { 
  cenário = 2
  } else if(mouseX >= 100 && mouseX <= 300 && mouseY >= 290 && mouseY <= 340 && borda === 290){
 cenário = 50
  }
  }
  
  //todos os códigos para as setas de cenários
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário !== 1 && cenário !== 1001 && cenário !== 1002 && cenário !== 1003 && cenário !== 1004 && cenário !== 1005 && cenário !== 1006 && cenário !== 1007 && cenário !== 1008 && cenário !== 1009 && cenário !== 1010 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109 && cenário !== 109 && cenário !== 110 && cenário !== 50){
    cenário = cenário - 1
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário !== 1 && cenário !== 1001 && cenário !== 1002 && cenário !== 1003 && cenário !== 1004 && cenário !== 1005 && cenário !== 1006 && cenário !== 1007 && cenário !== 1008 && cenário !== 1009 && cenário !== 1010 && cenário !== 101 && cenário !== 102 && cenário !== 103 && cenário !== 104 && cenário !== 105 && cenário !== 106 && cenário !== 107 && cenário !== 108 && cenário !== 109 && cenário !== 110 && cenário !== 50 && cenário !== 34 && liberar === 1 && cenário !== 36){
    cenário = cenário + 1
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1001){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1001 && liberar === 1){
    cenário = 101
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1002){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1002 && liberar === 1){
    cenário = 102
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1003){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1003 && liberar === 1){
    cenário = 103
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1004){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1004 && liberar === 1){
    cenário = 104
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1005){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1005 && liberar === 1){
    cenário = 105
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1006){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1006 && liberar === 1){
    cenário = 106
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1007){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1007 && liberar === 1){
    cenário = 107
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1008){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1008 && liberar === 1){
    cenário = 108
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1009){
    cenário = 35
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1009 && liberar === 1){
    cenário = 109
    initGame();
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1010){
    cenário = 36
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1010 && liberar === 1){
    cenário = 110
  }
  if(mouseX > 355 && mouseX < 395 && mouseY > 5 && mouseY < 25 && cenário === 1011 && liberar === 1){
    cenário = 111
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 1011){
    cenário = 36
  }
  if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 25 && cenário === 50){
    cenário = 1
  }
  
  //---------------------
  
  //codigo tecla jogar cenário 34
  if(cenário === 34){
  if(mouseX >= 90 && mouseX <= 310 && mouseY >= 280 && mouseY <= 350){
    cenário = 35
  }
  }
  
  //-----------------------
  
  if(cenário === 103){
  if (lock) return; // ignora cliques
  
  // Verifica se o clique ocorreu dentro de alguma carta
  for (let card of cards) {
    if (mouseX >= card.x && mouseX <= card.x + card.w &&
        mouseY >= card.y && mouseY <= card.y + card.h) {
      if (!card.flipped && !card.matched) {
        card.flipped = true;
        flippedCards.push(card);
      }
    }
  }
  
  if (flippedCards.length === 2) {
    lock = true;
    if (flippedCards[0].symbol === flippedCards[1].symbol) {
      flippedCards[0].matched = true;
      flippedCards[1].matched = true;
      flippedCards = [];
      lock = false;
    } else {
      setTimeout(() => {
        flippedCards[0].flipped = false;
        flippedCards[1].flipped = false;
        flippedCards = [];
        lock = false;
      }, 1000);
    }
  }
  }
  if(cenário === 108){
  for (let t of tesouros) {
    if (!t.found) {
      let d = dist(mouseX, mouseY, t.x, t.y);
      if (d < 30) {
        t.found = true;
        foundCount++;
      }
    }
  }
  }
  if (!gameEnded) {
    // Verifica cada bolinha para ver se o clique ocorreu sobre ela
    for (let i = balls.length - 1; i >= 0; i--) {
      let b = balls[i];
      let d = dist(mouseX, mouseY, b.x, b.y);
      if (d < b.radius) {
        score += 10;           // Soma 10 pontos por bolinha coletada
        balls.splice(i, 1);    // Remove a bolinha coletada
      }
    }
  }
  if (gameOver3) return;
  
  if(cenário === 102){
  // Verifica se o clique está dentro da área do tabuleiro
  if (mouseX < boardOffset || mouseX > boardOffset + boardSize ||
      mouseY < boardOffset || mouseY > boardOffset + boardSize) {
    return;
  }
  
  let col = floor((mouseX - boardOffset) / (boardSize / 3));
  let row = floor((mouseY - boardOffset) / (boardSize / 3));
  
  if (board[row][col] === '') {
    board[row][col] = currentPlayer;
    currentPlayer = (currentPlayer === "x") ? "o" : "x";
  }
  }
  
  //reflorestamento jogo
  if (gameStatus !== 0) return;
  // evita plantar sobre mato ou sobre outra árvore
  if (grassPatches.some(g => dist(mouseX, mouseY, g.x, g.y) < g.r)) return;
  if (trees.some(t => dist(mouseX, mouseY, t.x, t.y) < 15)) return;
  trees.push({ x: mouseX, y: mouseY });
}
//--------------------------------------

//Jogo caminhãozinho---------------------------------
function createCollectible() {
  return {
    x: floor(random(width / gridSize)) * gridSize,
    y: floor(random(height / gridSize)) * gridSize,
    item: random(collectibles),
  };
}

function restartGame() {
  gameOver = false;
  truck = new Truck();
  collectible = createCollectible();
}

class Truck {
  constructor() {
    this.body = [createVector(gridSize, gridSize)];
    this.xdir = 1;
    this.ydir = 0;
  }

  update() {
    let head = this.body[this.body.length - 1].copy();
    head.x += this.xdir * gridSize;
    head.y += this.ydir * gridSize;

    if (this.hitWall()) {
      gameOver = true;
      return;
    }

    this.body.push(head);

    if (!this.collecting) {
      this.body.shift();
    } else {
      this.collecting = false;
    }
  }

  show() {
    for (let i = 0; i < this.body.length; i++) {
      let segment = this.body[i];

      // Cor do caminhão
      fill(200, 0, 0);
      stroke(50);
      strokeWeight(2);
      rect(segment.x, segment.y, gridSize, gridSize, 5);

      // Caçamba traseira
      fill(150);
      rect(segment.x + 4, segment.y - 5, gridSize - 8, 10, 3);

      // Janelas do caminhão
      fill(180, 220, 255);
      rect(segment.x + 6, segment.y + 2, gridSize - 12, 10, 3);

      // Rodas
      fill(0);
      ellipse(segment.x + 5, segment.y + gridSize - 3, 6, 6);
      ellipse(segment.x + gridSize - 5, segment.y + gridSize - 3, 6, 6);
    }
  }
  setDirection(x, y) {
    this.xdir = x;
    this.ydir = y;
  }

  collect(position) {
    let head = this.body[this.body.length - 1];
    if (head.x === position.x && head.y === position.y) {
      this.collecting = true;
      return true;
    }
    return false;
  }

  checkCollision() {
    let head = this.body[this.body.length - 1];
    for (let i = 0; i < this.body.length - 1; i++) {
      if (head.x === this.body[i].x && head.y === this.body[i].y) {
        return true;
      }
    }
    return false;
  }

  hitWall() {
    let head = this.body[this.body.length - 1];
    return head.x < 0 || head.x >= width || head.y < 0 || head.y >= height;
  }
}

//jogo bolinhas----------------------------

function spawnBall() {
  let radius = random(15, 30);                        // Raio aleatório entre 15 e 30
  let x = random(radius, width - radius);             // Posição horizontal aleatória
  let y = -radius;                                    // Inicia acima da tela
  let speed = random(2, 6);                           // Velocidade aleatória
  balls.push(new Ball(x, y, radius, speed));
}

function spawnFireworks() {
  for (let i = 0; i < 100; i++) {
    let angle = random(TWO_PI);
    let speed = random(2, 6);
    fireworkParticles.push(new Firework(width/2, height/2, angle, speed));
  }
}
class Ball {
  constructor(x, y, radius, speed) {
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.speed = speed;
  }
  
  update() {
    this.y += this.speed;
  }
  
  display() {
    fill(255, 0, 0);
    noStroke();
    ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
  }
}

class Firework {
  constructor(x, y, angle, speed) {
    this.x = x;
    this.y = y;
    this.vx = speed * cos(angle);
    this.vy = speed * sin(angle);
    this.size = random(4, 8);
    this.color = color(random(200,255), random(100,255), random(100,255));
    this.life = 255;
  }
  
  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += 0.05;
    this.life -= 4;
  }
  
  display() {
    noStroke();
    fill(red(this.color), green(this.color), blue(this.color), this.life);
    ellipse(this.x, this.y, this.size, this.size);
  }
}
function drawProgressBar(x, y, w, h, value, maxVal, label, col) {
  stroke(0);
  fill(255);
  rect(x, y, w, h);
  noStroke();
  fill(col);
  let barWidth = map(value, 0, maxVal, 0, w);
  rect(x, y, barWidth, h);
  fill(0);
  textAlign(LEFT, CENTER);
  text(label + " (" + floor(value) + "/" + maxVal + ")", x, y + h + 12);
}


//jogo da velha -------------------------------------------

function drawBoard() {
  // Desenha o tabuleiro (grade) dentro da área de 350x350 com offset
  strokeWeight(4);
  // Linhas verticais
  for (let i = 1; i < 3; i++) {
    let x = boardOffset + i * (boardSize / 3);
    line(x, boardOffset, x, boardOffset + boardSize);
  }
  // Linhas horizontais
  for (let i = 1; i < 3; i++) {
    let y = boardOffset + i * (boardSize / 3);
    line(boardOffset, y, boardOffset + boardSize, y);
  }
  
  // Desenha as imagens nas células conforme a marcação
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      let x = boardOffset + j * (boardSize / 3);
      let y = boardOffset + i * (boardSize / 3);
      if (board[i][j] === "x") {
        image(imgX, x + 1, y, 114, 114);
      } else if (board[i][j] === "o") {
        image(imgO, x + 2, y + 3, 112, 111);
      }
    }
  }
}

function checkWinner() {
  let winner = null;
  
  // Verifica linhas
  for (let i = 0; i < 3; i++) {
    if (board[i][0] !== '' &&
        board[i][0] === board[i][1] &&
        board[i][1] === board[i][2]) {
      winner = board[i][0];
    }
  }
  
  // Verifica colunas
  for (let j = 0; j < 3; j++) {
    if (board[0][j] !== '' &&
        board[0][j] === board[1][j] &&
        board[1][j] === board[2][j]) {
      winner = board[0][j];
    }
  }
  
  // Verifica diagonais
  if (board[0][0] !== '' &&
      board[0][0] === board[1][1] &&
      board[1][1] === board[2][2]) {
    winner = board[0][0];
  }
  
  if (board[0][2] !== '' &&
      board[0][2] === board[1][1] &&
      board[1][1] === board[2][0]) {
    winner = board[0][2];
  }
  
  return winner;
}

function isBoardFull() {
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (board[i][j] === '') {
        return false;
      }
    }
  }
  return true;
}


//jogo arvores

function initGame() {
  temperature = 30;
  gameStatus = 0;
  trees = [];
  grassPatches = Array.from({ length: 20 }, () => ({
    x: random(20, width - 20),
    y: random(20, height - 20),
    r: 20
  }));
}

//jogo camêra

class Objeto {
  constructor(x, y, img, nome) {
    this.x = x;
    this.y = y;
    this.img = img;
    this.nome = nome;
    this.fotografado = false;
  }

  display() {
    imageMode(CENTER);
    image(this.img, this.x, this.y, 50, 50);
  }
}

//funções jogo elementos que caem

function telaExplicacao() {
  background(245, 235, 200);
  textAlign(CENTER);
  fill(60);
  textSize(24);
  strokeWeight(0)
  text("🎉 Conexão Campo-Cidade 🎉", width / 2, 60);
  textSize(16);
  text("Use ← → para mover e pegar produtos\n\nPegue 20 itens para vencer!\n\nPressione ➡️ para começar", width / 2, height / 2);
}

function jogar() {
  background(200, 255, 200);

  player.mostrar();
  player.mover();

  // Cria novo item aleatório a cada 30 frames
  if (frameCount % 30 === 0 && !venceu) {
    itens.push(new Item());
  }

  // Atualiza e desenha itens
  for (let i = itens.length - 1; i >= 0; i--) {
    itens[i].mover();
    itens[i].mostrar();

    if (itens[i].pego(player)) {
      itens.splice(i, 1);
      pontos2++;
    } else if (itens[i].foraDaTela()) {
      itens.splice(i, 1);
    }
  }

  // Exibe pontuação
  fill(0);
  textSize(18);
  textAlign(LEFT);
  text("Itens coletados: " + pontos2 + "/20", 10, 20);

  // Vitória
  if (pontos2 >= 20) {
    venceu = true;
    fill(0, 150, 0);
    strokeWeight(0)
    textAlign(CENTER);
    textSize(26);
    text("🎊 Você venceu! 🎊", width / 2, height / 2);
    textSize(16);
    text("Pressione ENTER para reiniciar", width / 2, height / 2 + 40);
    noLoop();
  }
}


class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 30;
    this.size = 40;
    this.vel = 5;
  }

  mostrar() {
    textAlign(CENTER, CENTER);
    textSize(32);
    text("🧺", this.x, this.y);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.vel;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.vel;
    }
    this.x = constrain(this.x, this.size / 2, width - this.size / 2);
  }
}

class Item {
  constructor() {
    this.x = random(20, width - 20);
    this.y = 0;
    this.vel = 3;
    this.emoji = random(emojisCampoCidade);
  }

  mover() {
    this.y += this.vel;
  }

  mostrar() {
    textAlign(CENTER, CENTER);
    textSize(28);
    text(this.emoji, this.x, this.y);
  }

  pego(player) {
    return dist(this.x, this.y, player.x, player.y) < 30;
  }

  foraDaTela() {
    return this.y > height + 20;
  }
}

//jogo corrida

function ativaJogo() {
  if (focused == true) {
    background("#D2EBB5");
  } else {
    background("rgb(238,178,178)");
  }
}

function desenhaJogadores() {
  textSize(40);
  for (let i = 0; i < quantidade; i++) {
    text(jogador[i], xJogador[i], yJogador[i]);
  }
}

function desenhaLinhaDeChegada() {
  fill("white");
  rect(350, 0, 10, 400);
  strokeWeight(1)
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350) {
      vencedor = true;
      noStroke()
      text(jogador[i] + " venceu!", 200, 200);
    }
  }
}

function keyReleased() {
  if(vencedor === false){
  for (let i = 0; i < quantidade; i++) {
    if (key == teclas[i]) {
      xJogador[i] += random(20);
    }
  }
  }
}
